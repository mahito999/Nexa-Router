# Changelog

All notable changes are documented here. The format follows [Keep a Changelog](https://keepachangelog.com/) and the project uses [Semantic Versioning](https://semver.org/).

## [0.1.0-alpha] - 2026-11-03

### Added
- Task classifier (English and Arabic) for ten task categories
- Routing engine with Auto, Fast, Best quality, Free-first and Compare modes
- Automatic fallback with typed error handling (rate limit, quota, transient, timeout, connection, authentication, invalid request), cooldowns, bounded retries and an attempt cap
- Adapters for OpenAI, Anthropic, Google Gemini, OpenRouter, Ollama and generic OpenAI-compatible endpoints; provider plugin registry
- Image generation, text-to-speech and speech-to-text endpoints (shown only when a capable provider exists)
- FastAPI REST API with SQLite storage (PostgreSQL-ready), per-user conversations and usage tracking that separates provider-reported, locally counted and unknown quota
- Security: encrypted key storage, environment-variable keys, log redaction, URL validation, rate limiting, bearer-token auth with admin / user roles, per-user daily limits
- React + TypeScript + Tailwind interface (Arabic RTL / English) with Chat, Models, Providers, Routing, Usage, History and Settings pages; installable as a PWA
- Docker image and Compose file (optional Ollama profile), Termux install / run scripts
- GitHub scaffolding: CI, CodeQL, dependency review, release workflow, issue and PR templates, Dependabot

### Known limitations
- No streaming responses yet
- Video generation has no built-in adapter
- API layer, adapters and frontend have not yet been verified against real provider accounts
- No database migrations; in-memory rate limiter (single instance)
