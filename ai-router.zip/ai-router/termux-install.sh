#!/data/data/com.termux/files/usr/bin/bash
# One-time setup for Android (Termux from F-Droid).  Usage:  bash termux-install.sh
set -e
cd "$(dirname "$0")"

echo "==> Installing system packages"
pkg update -y
pkg install -y python nodejs rust binutils clang make libffi openssl

echo "==> Building the frontend"
(cd frontend && npm install --no-audit --no-fund && npm run build)

echo "==> Installing the backend (compiling some packages can take 10-20 minutes)"
(cd backend && python -m venv .venv && . .venv/bin/activate \
  && pip install --upgrade pip && pip install -r requirements.txt)

echo
echo "Done. Start the app with:  bash termux-run.sh"
