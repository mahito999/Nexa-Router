#!/data/data/com.termux/files/usr/bin/bash
# Start AI Router on Android (Termux).  Usage:  bash termux-run.sh
cd "$(dirname "$0")/backend" || exit 1
. .venv/bin/activate

# Optional: load ../.env (the app does not read .env by itself)
if [ -f ../.env ]; then set -a; . ../.env; set +a; fi

export FRONTEND_DIST=../frontend/dist
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock   # keep running with screen off

URL="http://localhost:8000"
echo "AI Router -> $URL   (Ctrl+C to stop)"
# Open the browser automatically if the termux-api package is installed
if command -v termux-open-url >/dev/null 2>&1; then (sleep 4; termux-open-url "$URL") & fi

exec uvicorn app.main:get_app --factory --host 127.0.0.1 --port 8000
