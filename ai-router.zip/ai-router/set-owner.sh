#!/usr/bin/env bash
# Replace the OWNER placeholder with your GitHub username.  Usage: bash set-owner.sh yourname
set -e
[ -n "$1" ] || { echo "usage: bash set-owner.sh <github-username>"; exit 1; }
cd "$(dirname "$0")"
grep -rIl "OWNER/ai-router" . --exclude-dir=node_modules --exclude-dir=.git --exclude=set-owner.sh \
  | xargs sed -i "s#OWNER/ai-router#$1/ai-router#g"
echo "Done. Repository URLs now point to github.com/$1/ai-router"
