<div align="center">

# 🔀 AI Router

**A free, open-source, self-hosted platform that routes every request to the best available AI model, and switches automatically when one fails.**
Cloud APIs and local models in one place. Arabic-first (RTL) dark interface, English included.

[![CI](https://github.com/OWNER/ai-router/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/OWNER/ai-router/actions/workflows/ci.yml)
[![CodeQL](https://github.com/OWNER/ai-router/actions/workflows/codeql.yml/badge.svg?branch=main)](https://github.com/OWNER/ai-router/actions/workflows/codeql.yml)
[![Dependency Review](https://github.com/OWNER/ai-router/actions/workflows/dependency-review.yml/badge.svg?branch=main)](https://github.com/OWNER/ai-router/actions/workflows/dependency-review.yml)
[![Release](https://github.com/OWNER/ai-router/actions/workflows/release.yml/badge.svg)](https://github.com/OWNER/ai-router/actions/workflows/release.yml)
[![GitHub Release](https://img.shields.io/github/v/release/OWNER/ai-router?include_prereleases)](https://github.com/OWNER/ai-router/releases)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![GitHub Repo stars](https://img.shields.io/github/stars/OWNER/ai-router)](https://github.com/OWNER/ai-router/stargazers)
[![GitHub Issues](https://img.shields.io/github/issues/OWNER/ai-router)](https://github.com/OWNER/ai-router/issues)

[**Quick start**](#quick-start) · [**Documentation**](docs/README.md) · [**Roadmap**](#roadmap) · [**FAQ**](#faq)

</div>

---

## Table of Contents

- [What is AI Router?](#what-is-ai-router)
- [Features](#features)
- [Supported providers](#supported-providers)
- [Quick start](#quick-start)
- [Configuration](#configuration)
- [Documentation](#documentation)
- [Project status](#project-status)
- [Roadmap](#roadmap)
- [FAQ](#faq)
- [License](#license)

---

## What is AI Router?

You configure the AI providers you already have access to (OpenAI, Anthropic, Gemini, OpenRouter, Ollama or any OpenAI-compatible server). AI Router analyses each request, works out the task (coding, writing, translation, math…), picks the most suitable **available** model, and if that model returns a rate-limit, quota, server or timeout error it moves on to the next compatible one, keeping the conversation context, and tells you which model actually answered.

> **Honest by design.** Fallback moves a request to *another provider you configured*. It never transfers, pools or bypasses any provider's quota, subscription or authentication, and it never scrapes private consumer chat interfaces. Quota figures are labelled *provider-reported*, *locally counted* or *unknown*; nothing is invented.

---

## Features

- 🧭 **Task-aware routing**: general chat, programming, web research, writing, translation, document analysis, math, image / video / audio generation (English and Arabic heuristics, with manual override)
- 🔁 **Automatic fallback**: handles 429, quota exhaustion, 5xx, timeouts and connection errors; auth errors are never retried; capped attempts; no retry loops
- 🎛️ **Five modes**: Auto, Fast, Best quality, Free-first (local and free models first), Compare (side by side)
- 🔌 **Hybrid providers**: cloud APIs, Ollama, any OpenAI-compatible endpoint, and a plugin system for new ones
- 🔐 **Keys stay on the server**: encrypted at rest or read from environment variables; never sent to the browser
- 📊 **Usage dashboard**: requests, failures, error types, tokens, optional cost estimates, availability
- 🖼️ **Media**: image generation, text-to-speech and speech-to-text, shown only when a capable provider is configured
- 🌍 **Arabic-first UI**: full RTL, English option, dark theme, mobile-friendly, installable as a phone app (PWA)
- 🛡️ **Security basics**: input validation, rate limiting, log redaction, SSRF guard, optional bearer-token auth with roles, per-user limits
- 🆓 **MIT licensed**: no paywalls, no ads, no telemetry, no third-party requests from the UI

---

## Supported providers

| Provider | Kind | Needs |
|---|---|---|
| OpenAI | `openai` | API key |
| Anthropic (Claude) | `anthropic` | API key |
| Google Gemini | `gemini` | API key |
| OpenRouter | `openrouter` | API key |
| Ollama (local) | `ollama` | running Ollama server |
| LM Studio, vLLM, llama.cpp, Groq, Together… | `openai_compatible` | base URL (+ key if required) |
| Anything else | plugin | see [docs/PROVIDERS.md](docs/PROVIDERS.md) |

---

## Quick start

### Docker (any OS)

```bash
git clone https://github.com/OWNER/ai-router.git && cd ai-router
cp .env.example .env
docker compose up --build            # http://localhost:8000
docker compose --profile local up --build   # plus a local Ollama container
```

### Linux / macOS

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:get_app --factory --reload --port 8000

# second terminal
cd frontend && npm install && npm run dev      # http://localhost:5173
```

### Windows (PowerShell)

```powershell
cd backend; py -m venv .venv; .\.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
uvicorn app.main:get_app --factory --reload --port 8000
# second terminal
cd frontend; npm install; npm run dev
```

### Android (Termux, phone only)

Install Termux from **F-Droid**, copy the project to the phone, then:

```bash
bash termux-install.sh   # one time (10–20 min)
bash termux-run.sh       # open http://localhost:8000
```

In Chrome use ⋮ → *Add to Home screen* to install it like an app. An installable **APK** is built by the *Android APK* workflow (it connects to your server; see [docs/BUILDING.md](docs/BUILDING.md#android-apk)).

Then open **Providers → Add**, enter a key, press **Test connection** and **Discover models**. Details in [docs/USAGE.md](docs/USAGE.md).

---

## Configuration

Settings are environment variables ([`.env.example`](.env.example)) plus the in-app pages. Nothing has a default secret, and `.env` is git-ignored.

| Variable | Purpose |
|---|---|
| `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `OPENROUTER_API_KEY` | provider keys (or add keys in the UI) |
| `DATABASE_URL` | SQLite by default; PostgreSQL-ready |
| `APP_SECRET_KEY` | Fernet key for stored keys (auto-generated if empty) |
| `AI_ROUTER_API_TOKENS` | `token:user:role,...`; empty disables authentication |
| `RATE_LIMIT_PER_MINUTE`, `USER_DAILY_REQUEST_LIMIT`, `USER_DAILY_TOKEN_LIMIT` | limits; `0` means unlimited |
| `AI_ROUTER_PLUGINS` | extra provider modules to load |

---

## Documentation

All documentation lives in [`docs/`](docs/README.md): [usage](docs/USAGE.md), [architecture](docs/ARCHITECTURE.md), [building](docs/BUILDING.md), [providers](docs/PROVIDERS.md), [privacy](docs/PRIVACY.md), [contributing](docs/CONTRIBUTING.md) and [security policy](docs/SECURITY.md).

---

## Project status

**0.1.0-alpha.** The routing engine, fallback logic, error classification and security helpers are covered by 70 automated tests. The API layer, provider adapters and frontend are written with mocked-HTTP tests, but have **not yet been verified against real provider accounts**; please report what you find. See [CHANGELOG.md](CHANGELOG.md).

---

## Roadmap

### Phase 1: Foundation *(current)*
- [x] Task classifier (English + Arabic)
- [x] Router with modes, scoring and bounded fallback
- [x] OpenAI, Anthropic, Gemini, OpenRouter, Ollama and OpenAI-compatible adapters
- [x] Provider management, routing settings, usage dashboard, history
- [x] Encrypted key storage, auth roles, rate limiting, log redaction
- [x] Docker, Termux scripts, CI
- [ ] Verification against real provider accounts

### Phase 2: Quality
- [ ] Streaming responses
- [ ] Alembic migrations
- [ ] Frontend unit / end-to-end tests
- [ ] Shared (Redis) rate limiter for multi-instance deployments

### Phase 3: More capabilities
- [ ] Video generation adapters
- [ ] File / document upload for analysis
- [ ] More interface languages
- [ ] Optional live web-search tool integration

---

## FAQ

**Does it combine or share my free quotas across providers?** No. It only tries other providers you configured, each under its own account and limits.

**Where are my API keys?** On your server only, encrypted, or in environment variables. They are never returned by the API or shown in the browser.

**Can it work fully offline?** Yes, with Ollama or another local server. The interface makes no third-party requests.

**Why do video buttons not appear?** Video generation has an interface but no built-in adapter yet. Controls appear only for capabilities a configured provider really supports.

**Can I limit or unlimit usage?** Rate and daily limits are configurable; `0` disables each of them.

---

## License

[MIT](LICENSE). Use it for anything, commercial or not.
