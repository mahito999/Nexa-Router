import asyncio
from typing import List

from app.routing.router import HealthTracker, Router
from app.routing.types import (CAP_IMAGE, CAP_TEXT, CAP_WEB, ChatResult,
                               ModelSpec, ProviderRuntime, RoutingSettings)


def run(coro):
    return asyncio.run(coro)


class FakeAdapter:
    """Scripted adapter: each call pops the next item (exception or text)."""

    def __init__(self, script):
        self.script = list(script)
        self.calls = []

    async def chat(self, model, messages, **kw):
        self.calls.append((model, [(m.role, m.content) for m in messages]))
        item = self.script.pop(0) if self.script else "ok"
        if isinstance(item, BaseException):
            raise item
        if callable(item):
            return await item()
        return ChatResult(item, 10, 5)


def provider(pid, script=("ok",), *, models=None, priority=100, local=False,
             enabled=True):
    models = models or [ModelSpec("m-" + pid, {CAP_TEXT}, quality=5, speed=5)]
    return ProviderRuntime(pid, "fake", FakeAdapter(script), models, priority,
                           enabled, local)


def make_router(providers: List[ProviderRuntime], **settings) -> Router:
    async def no_sleep(_):
        return None
    s = RoutingSettings(**settings)
    return Router(lambda: providers, settings=s, sleep=no_sleep,
                  health=HealthTracker())
