import logging

import pytest

from app import security
from app.errors import (AuthenticationError, InvalidRequestError,
                        ModelNotFoundError, QuotaExhaustedError,
                        RateLimitError, TransientError, classify_http_error)


# ------------------------------------------------ quota / auth classification
def test_plain_429_is_rate_limit_with_retry_after():
    e = classify_http_error(429, "slow down", {"Retry-After": "12"})
    assert isinstance(e, RateLimitError) and e.cooldown == 12


@pytest.mark.parametrize("body", [
    '{"error":{"code":"insufficient_quota"}}',
    "You exceeded your current quota, please check your plan and billing",
    '{"status":"RESOURCE_EXHAUSTED"}',
])
def test_429_with_quota_text_is_quota_exhausted(body):
    assert isinstance(classify_http_error(429, body), QuotaExhaustedError)


def test_billing_style_400_and_402_are_quota():
    assert isinstance(classify_http_error(400, "Your credit balance is too low"), QuotaExhaustedError)
    assert isinstance(classify_http_error(402), QuotaExhaustedError)


@pytest.mark.parametrize("status,body", [(401, ""), (403, "forbidden"),
                                         (400, "API key not valid. Please pass a valid API key.")])
def test_auth_errors_are_permanent(status, body):
    e = classify_http_error(status, body)
    assert isinstance(e, AuthenticationError) and e.permanent and not e.retry_same


@pytest.mark.parametrize("status", [500, 502, 503, 504, 529])
def test_server_errors_are_transient(status):
    e = classify_http_error(status)
    assert isinstance(e, TransientError) and e.retry_same


def test_404_and_400_classification():
    assert isinstance(classify_http_error(404), ModelNotFoundError)
    e = classify_http_error(400, "messages: field required")
    assert isinstance(e, InvalidRequestError) and not e.failover


# ------------------------------------------------------------ secret handling
def test_redact_removes_keys_and_registered_secrets():
    security.register_secret("my-custom-secret-value")
    text = ("calling with sk-abcdef1234567890 and Bearer abc.def.ghi12345 "
            "x-api-key: topsecretvalue and my-custom-secret-value AIzaSyA-1234567890abc")
    out = security.redact(text)
    for leaked in ("sk-abcdef1234567890", "abc.def.ghi12345", "topsecretvalue",
                   "my-custom-secret-value", "AIzaSyA-1234567890abc"):
        assert leaked not in out


def test_log_filter_redacts(caplog):
    security.install_log_redaction()
    logger = logging.getLogger("t")
    with caplog.at_level(logging.INFO):
        logger.info("key=sk-should-not-appear-123456")
    assert "should-not-appear" not in caplog.text or "[REDACTED]" in caplog.text


def test_secretbox_roundtrip_and_key_file_permissions(tmp_path):
    kf = str(tmp_path / "data" / ".secret_key")
    box = security.SecretBox.load_or_create(None, kf)
    token = box.encrypt("sk-live-123456")
    assert "sk-live" not in token
    assert security.SecretBox.load_or_create(None, kf).decrypt(token) == "sk-live-123456"
    assert (tmp_path / "data" / ".secret_key").stat().st_mode & 0o077 == 0
    other = security.SecretBox.load_or_create(None, str(tmp_path / "other"))
    assert other.decrypt(token) is None


@pytest.mark.parametrize("url", ["file:///etc/passwd", "ftp://x.com", "javascript:alert(1)",
                                 "http://169.254.169.254/latest", "http://metadata.google.internal/",
                                 "https://user:pw@example.com", "", "not a url"])
def test_unsafe_base_urls_rejected(url):
    with pytest.raises(ValueError):
        security.validate_base_url(url)


@pytest.mark.parametrize("url", ["http://localhost:11434", "https://api.openai.com/v1/",
                                 "http://192.168.1.10:8000"])
def test_valid_base_urls_accepted(url):
    assert security.validate_base_url(url) == url.rstrip("/")


# ----------------------------------------------------- limiter / auth tokens
def test_rate_limiter_blocks_then_recovers():
    t = [0.0]
    rl = security.RateLimiter(2, 10, clock=lambda: t[0])
    assert rl.allow("u") and rl.allow("u") and not rl.allow("u")
    assert rl.allow("other")
    t[0] = 11
    assert rl.allow("u")
    assert security.RateLimiter(0).allow("x")  # 0 = unlimited


def test_token_parsing_and_authentication():
    toks = security.parse_tokens("abc123:alice:admin,def456:bob")
    assert security.authenticate(toks, "Bearer abc123").is_admin
    assert security.authenticate(toks, "Bearer def456").role == "user"
    assert security.authenticate(toks, "Bearer wrong") is None
    assert security.authenticate(toks, None) is None
    assert security.parse_tokens("") == {}
    with pytest.raises(ValueError):
        security.parse_tokens("justtoken")
    with pytest.raises(ValueError):
        security.parse_tokens("t:u:root")
