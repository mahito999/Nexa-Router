import asyncio

import pytest

from app.errors import (AllProvidersFailedError, AuthenticationError,
                        InvalidRequestError, NoEligibleModelError,
                        QuotaExhaustedError, RateLimitError,
                        RequestRejectedError, TransientError)
from app.routing.types import (CAP_IMAGE, CAP_TEXT, CAP_WEB, ChatMessage,
                               ModelSpec)

from .helpers import make_router, provider, run

MSGS = [ChatMessage("user", "first"), ChatMessage("assistant", "reply"),
        ChatMessage("user", "write python code")]


# ------------------------------------------------------- provider selection
def test_auto_picks_highest_quality_then_priority():
    hi = provider("hi", models=[ModelSpec("big", {CAP_TEXT}, quality=9, speed=4)])
    lo = provider("lo", models=[ModelSpec("small", {CAP_TEXT}, quality=4, speed=9)])
    plan = make_router([lo, hi]).plan("programming", "auto")
    assert [c.label for c in plan.candidates] == ["hi/big", "lo/small"]


def test_fast_and_best_modes_reorder():
    slow = provider("slow", models=[ModelSpec("deep", {CAP_TEXT}, quality=10, speed=2)])
    quick = provider("quick", models=[ModelSpec("tiny", {CAP_TEXT}, quality=5, speed=10)])
    r = make_router([slow, quick])
    assert r.plan("general_chat", "fast").candidates[0].label == "quick/tiny"
    assert r.plan("general_chat", "best").candidates[0].label == "slow/deep"


def test_free_first_prefers_local_and_free():
    cloud = provider("cloud", models=[ModelSpec("pro", {CAP_TEXT}, quality=10, speed=9)])
    local = provider("ollama", local=True,
                     models=[ModelSpec("llama", {CAP_TEXT}, quality=4, speed=4)])
    free = provider("free", models=[ModelSpec("f", {CAP_TEXT}, quality=3, speed=3, free=True)])
    labels = [c.label for c in make_router([cloud, free, local]).plan("general_chat", "free_first").candidates]
    assert labels[-1] == "cloud/pro" and set(labels[:2]) == {"ollama/llama", "free/f"}


def test_strengths_boost_matching_task():
    gen = provider("gen", models=[ModelSpec("g", {CAP_TEXT}, quality=6, speed=5)])
    cod = provider("cod", models=[ModelSpec("c", {CAP_TEXT}, quality=5, speed=5,
                                            strengths={"programming"})])
    assert make_router([gen, cod]).plan("programming").candidates[0].label == "cod/c"


def test_disabled_and_incapable_models_are_excluded():
    off = provider("off", enabled=False)
    txt = provider("txt")
    plan = make_router([off, txt]).plan("image_generation")
    assert plan.candidates == []
    plan = make_router([off, txt]).plan("general_chat")
    assert [c.provider.id for c in plan.candidates] == ["txt"]
    assert {"model": "off/m-off", "reason": "provider_disabled"} in plan.skipped


def test_media_task_requires_matching_capability():
    img = provider("img", models=[ModelSpec("im", {CAP_IMAGE})])
    txt = provider("txt")
    assert [c.label for c in make_router([img, txt]).plan("image_generation").candidates] == ["img/im"]


def test_web_research_warns_when_no_web_model():
    plan = make_router([provider("txt")]).plan("web_research")
    assert plan.candidates and any("no_web_search_model" in w for w in plan.warnings)
    web = provider("web", models=[ModelSpec("w", {CAP_TEXT, CAP_WEB})])
    plan = make_router([provider("txt"), web]).plan("web_research")
    assert [c.label for c in plan.candidates] == ["web/w"] and not plan.warnings


def test_strict_fallback_order_is_respected():
    a = provider("a", models=[ModelSpec("a1", {CAP_TEXT}, quality=9)])
    b = provider("b", models=[ModelSpec("b1", {CAP_TEXT}, quality=2)])
    r = make_router([a, b], strict_fallback_order=True, fallback_order=["b", "a"])
    assert [c.provider.id for c in r.plan("general_chat").candidates] == ["b", "a"]


def test_unknown_mode_or_task_rejected():
    r = make_router([provider("a")])
    with pytest.raises(ValueError):
        r.plan("general_chat", "turbo")
    with pytest.raises(ValueError):
        r.plan("nonsense")


# ------------------------------------------------------------------ fallback
def test_quota_error_falls_back_and_reports_actual_model():
    claude = provider("claude", [QuotaExhaustedError("q", status=429)],
                      models=[ModelSpec("c", {CAP_TEXT}, quality=9)])
    gpt = provider("gpt", ["gpt answer"], models=[ModelSpec("g", {CAP_TEXT}, quality=8)])
    out = run(make_router([claude, gpt]).chat(MSGS, "programming"))
    assert out.provider_id == "gpt" and out.content == "gpt answer"
    assert out.fallback_used is True
    assert [a["status"] for a in out.attempts] == ["failed", "success"]
    assert out.attempts[0]["error_type"] == "quota_exhausted"


def test_conversation_context_preserved_across_fallback():
    a = provider("a", [RateLimitError("429", status=429)],
                 models=[ModelSpec("a", {CAP_TEXT}, quality=9)])
    b = provider("b", models=[ModelSpec("b", {CAP_TEXT}, quality=5)])
    run(make_router([a, b]).chat(MSGS, "general_chat"))
    expected = [(m.role, m.content) for m in MSGS]
    assert a.adapter.calls[0][1] == expected and b.adapter.calls[0][1] == expected


def test_rate_limit_puts_provider_in_cooldown_for_next_request():
    a = provider("a", [RateLimitError("429", retry_after=60)],
                 models=[ModelSpec("a", {CAP_TEXT}, quality=9)])
    b = provider("b", models=[ModelSpec("b", {CAP_TEXT}, quality=5)])
    r = make_router([a, b])
    run(r.chat(MSGS, "general_chat"))
    plan = r.plan("general_chat")
    assert [c.provider.id for c in plan.candidates] == ["b"]
    assert {"model": "a/a", "reason": "cooling_down"} in plan.skipped


def test_fallback_to_local_when_cloud_unavailable():
    c1 = provider("c1", [TransientError("503", status=503)] * 3,
                  models=[ModelSpec("x", {CAP_TEXT}, quality=9)])
    local = provider("ollama", ["local answer"], local=True,
                     models=[ModelSpec("llama", {CAP_TEXT}, quality=3)])
    out = run(make_router([c1, local]).chat(MSGS, "general_chat"))
    assert out.provider_id == "ollama" and out.content == "local answer"


def test_authentication_error_not_retried_and_provider_parked():
    a = provider("a", [AuthenticationError("401", status=401)] * 5,
                 models=[ModelSpec("a", {CAP_TEXT}, quality=9)])
    b = provider("b", models=[ModelSpec("b", {CAP_TEXT}, quality=5)])
    r = make_router([a, b])
    out = run(r.chat(MSGS, "general_chat"))
    assert len(a.adapter.calls) == 1          # never retried
    assert out.provider_id == "b"
    assert r.health.status("a") == "auth_failed"
    run(r.chat(MSGS, "general_chat"))
    assert len(a.adapter.calls) == 1          # and not tried again
    r.health.reset("a")                       # config changed -> usable again
    assert r.health.status("a") == "available"


def test_transient_errors_retry_once_then_fail_over():
    a = provider("a", [TransientError("503")] * 5,
                 models=[ModelSpec("a", {CAP_TEXT}, quality=9)])
    b = provider("b", models=[ModelSpec("b", {CAP_TEXT}, quality=5)])
    out = run(make_router([a, b], transient_retries=1).chat(MSGS, "general_chat"))
    assert len(a.adapter.calls) == 2 and out.provider_id == "b"


def test_transient_error_recovers_on_retry_without_fallback():
    a = provider("a", [TransientError("503"), "recovered"])
    out = run(make_router([a]).chat(MSGS, "general_chat"))
    assert out.content == "recovered" and out.fallback_used is True  # 2 attempts
    assert out.provider_id == "a"


def test_timeout_is_handled_and_falls_back():
    async def hang():
        await asyncio.sleep(5)

    a = provider("a", [hang, hang], models=[ModelSpec("a", {CAP_TEXT}, quality=9)])
    b = provider("b", models=[ModelSpec("b", {CAP_TEXT}, quality=5)])
    r = make_router([a, b], request_timeout=0.05, transient_retries=1)
    out = run(r.chat(MSGS, "general_chat"))
    assert out.provider_id == "b"
    assert [a_["error_type"] for a_ in out.attempts[:2]] == ["timeout", "timeout"]


def test_no_infinite_loop_total_attempts_capped():
    ps = [provider(f"p{i}", [TransientError("503")] * 10) for i in range(5)]
    with pytest.raises(AllProvidersFailedError) as ei:
        run(make_router(ps, max_total_attempts=4, transient_retries=3).chat(MSGS, "general_chat"))
    assert len(ei.value.attempts) == 4
    assert sum(len(p.adapter.calls) for p in ps) == 4


def test_invalid_request_is_not_failed_over():
    a = provider("a", [InvalidRequestError("bad", status=400)],
                 models=[ModelSpec("a", {CAP_TEXT}, quality=9)])
    b = provider("b", models=[ModelSpec("b", {CAP_TEXT}, quality=5)])
    with pytest.raises(RequestRejectedError):
        run(make_router([a, b]).chat(MSGS, "general_chat"))
    assert b.adapter.calls == []


def test_no_eligible_model_raises_with_skip_reasons():
    with pytest.raises(NoEligibleModelError) as ei:
        run(make_router([provider("off", enabled=False)]).chat(MSGS, "general_chat"))
    assert ei.value.skipped


def test_success_attempt_has_no_error_and_usage_sink_called():
    events = []
    a = provider("a")
    r = make_router([a])
    r.usage_sink = events.append
    run(r.chat(MSGS, "general_chat"))
    assert events[0]["success"] is True and events[0]["prompt_tokens"] == 10


# ------------------------------------------------------------------- compare
def test_compare_runs_multiple_models_and_reports_errors():
    a = provider("a", ["A says hi"], models=[ModelSpec("a", {CAP_TEXT}, quality=9)])
    b = provider("b", [RateLimitError("429")], models=[ModelSpec("b", {CAP_TEXT}, quality=7)])
    c = provider("c", ["C says hi"], models=[ModelSpec("c", {CAP_TEXT}, quality=5)])
    res = run(make_router([a, b, c]).compare(MSGS, "general_chat", count=3))
    by = {r["provider"]: r for r in res}
    assert by["a"]["ok"] and by["a"]["content"] == "A says hi"
    assert not by["b"]["ok"] and by["b"]["error_type"] == "rate_limit"
    assert by["c"]["ok"]
