"""End-to-end API tests with mocked upstream providers. Skipped automatically
when fastapi/httpx/sqlalchemy are not installed."""
import pytest

pytest.importorskip("fastapi")
httpx = pytest.importorskip("httpx")
pytest.importorskip("sqlalchemy")
from fastapi.testclient import TestClient  # noqa: E402

from app.config import Settings  # noqa: E402
from app.main import create_app  # noqa: E402

OPENAI_OK = {"choices": [{"message": {"content": "from openai"}}],
             "usage": {"prompt_tokens": 5, "completion_tokens": 2}}


def make_client(tmp_path, handler, **kw):
    s = Settings(database_url="sqlite://", data_dir=str(tmp_path), rate_limit_per_minute=0, **kw)
    return TestClient(create_app(s, transport=httpx.MockTransport(handler)))


def add(c, pid, kind, key="sk-test-key-123456", models=None, priority=100, headers=None):
    r = c.post("/api/providers", headers=headers or {}, json={
        "id": pid, "name": pid, "kind": kind, "api_key": key, "priority": priority,
        "models": models or [{"name": "m1", "capabilities": ["text"], "quality": 8, "speed": 5}]})
    assert r.status_code == 201, r.text
    return r.json()


def test_api_key_never_returned(tmp_path):
    c = make_client(tmp_path, lambda r: httpx.Response(200, json=OPENAI_OK))
    created = add(c, "oa", "openai")
    assert "sk-test-key" not in str(created) and created["key_source"] == "stored"
    assert "sk-test-key" not in c.get("/api/providers").text


def test_chat_fallback_from_quota_error(tmp_path):
    def h(req):
        if "anthropic" in req.url.host:
            return httpx.Response(429, text="credit balance too low")
        return httpx.Response(200, json=OPENAI_OK)
    c = make_client(tmp_path, h)
    add(c, "claude", "anthropic", models=[{"name": "c1", "capabilities": ["text"], "quality": 10, "speed": 5}])
    add(c, "oa", "openai")
    r = c.post("/api/chat", json={"message": "write python code to sort a list"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["provider"] == "oa" and body["fallback_used"] and body["task"] == "programming"
    assert body["attempts"][0]["error_type"] == "quota_exhausted"
    # context preserved on follow-up
    r2 = c.post("/api/chat", json={"message": "and reverse?", "conversation_id": body["conversation_id"]})
    assert r2.status_code == 200


def test_no_provider_gives_clear_error(tmp_path):
    c = make_client(tmp_path, lambda r: httpx.Response(200, json=OPENAI_OK))
    r = c.post("/api/chat", json={"message": "hello"})
    assert r.status_code == 503 and r.json()["detail"]["code"] == "no_eligible_model"


def test_media_not_offered_without_provider(tmp_path):
    c = make_client(tmp_path, lambda r: httpx.Response(200, json=OPENAI_OK))
    add(c, "oa", "openai")
    assert c.get("/api/capabilities").json()["image_generation"]["available"] is False
    assert c.post("/api/media/image", json={"prompt": "a fox"}).status_code == 409


def test_invalid_requests_rejected(tmp_path):
    c = make_client(tmp_path, lambda r: httpx.Response(200, json=OPENAI_OK))
    assert c.post("/api/chat", json={"message": ""}).status_code == 422
    assert c.post("/api/chat", json={"message": "x", "mode": "turbo"}).status_code == 422
    assert c.post("/api/chat", json={"message": "x", "task": "nonsense"}).status_code == 422
    assert c.post("/api/providers", json={"id": "Bad ID!", "name": "x", "kind": "openai"}).status_code == 422
    r = c.post("/api/providers", json={"id": "evil", "name": "x", "kind": "openai_compatible",
                                       "base_url": "http://169.254.169.254/latest"})
    assert r.status_code == 422 and r.json()["detail"]["code"] == "invalid_base_url"


def test_auth_and_roles(tmp_path):
    c = make_client(tmp_path, lambda r: httpx.Response(200, json=OPENAI_OK),
                    api_tokens="adm:alice:admin,usr:bob")
    assert c.get("/api/providers").status_code == 401
    assert c.get("/api/providers", headers={"authorization": "Bearer nope"}).status_code == 401
    user = {"authorization": "Bearer usr"}
    assert c.get("/api/providers", headers=user).status_code == 200
    r = c.post("/api/providers", headers=user, json={"id": "oa", "name": "x", "kind": "openai"})
    assert r.status_code == 403
    add(c, "oa", "openai", headers={"authorization": "Bearer adm"})


def test_conversations_are_private_per_user(tmp_path):
    c = make_client(tmp_path, lambda r: httpx.Response(200, json=OPENAI_OK), api_tokens="a:alice:admin,b:bob")
    add(c, "oa", "openai", headers={"authorization": "Bearer a"})
    cid = c.post("/api/chat", headers={"authorization": "Bearer a"}, json={"message": "hi"}).json()["conversation_id"]
    assert c.get(f"/api/conversations/{cid}", headers={"authorization": "Bearer b"}).status_code == 404


def test_daily_limit_enforced(tmp_path):
    c = make_client(tmp_path, lambda r: httpx.Response(200, json=OPENAI_OK), user_daily_request_limit=1)
    add(c, "oa", "openai")
    assert c.post("/api/chat", json={"message": "one"}).status_code == 200
    assert c.post("/api/chat", json={"message": "two"}).status_code == 429


def test_usage_distinguishes_quota_sources(tmp_path):
    c = make_client(tmp_path, lambda r: httpx.Response(200, json=OPENAI_OK))
    add(c, "oa", "openai")
    c.post("/api/chat", json={"message": "hi"})
    p = c.get("/api/usage").json()["providers"][0]
    assert p["requests"] == 1 and p["successful"] == 1 and p["quota"]["status"] == "unknown"
    assert p["est_cost_usd"] is None   # no pricing configured -> not invented
