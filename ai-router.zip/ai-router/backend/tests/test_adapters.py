"""Adapter tests using httpx.MockTransport. Skipped automatically when httpx is
not installed (run `pip install -r requirements-dev.txt` first)."""
import asyncio
import json

import pytest

httpx = pytest.importorskip("httpx")

from app.errors import (AuthenticationError, ProviderConnectionError,  # noqa: E402
                        ProviderTimeoutError, QuotaExhaustedError,
                        RateLimitError, TransientError)
from app.providers.anthropic import AnthropicAdapter  # noqa: E402
from app.providers.gemini import GeminiAdapter  # noqa: E402
from app.providers.ollama import OllamaAdapter  # noqa: E402
from app.providers.openai_compat import OpenAIAdapter  # noqa: E402
from app.routing.types import ChatMessage  # noqa: E402

MSGS = [ChatMessage("system", "be brief"), ChatMessage("user", "hi")]


def adapter(cls, handler, base="http://x", key="k-123456"):
    return cls(base, key, httpx.AsyncClient(transport=httpx.MockTransport(handler)))


def call(a, **kw):
    return asyncio.run(a.chat("m", MSGS, max_tokens=50, temperature=None, timeout=5, **kw))


def test_openai_request_shape_and_parsing():
    seen = {}

    def h(req):
        seen["auth"] = req.headers["authorization"]; seen["body"] = json.loads(req.content)
        return httpx.Response(200, json={"choices": [{"message": {"content": "yo"}}],
                                         "usage": {"prompt_tokens": 3, "completion_tokens": 1}},
                              headers={"x-ratelimit-remaining-requests": "99"})
    r = call(adapter(OpenAIAdapter, h))
    assert r.text == "yo" and (r.prompt_tokens, r.completion_tokens) == (3, 1)
    assert r.quota_info == {"requests_remaining": "99"}
    assert seen["auth"] == "Bearer k-123456" and seen["body"]["max_completion_tokens"] == 50
    assert "temperature" not in seen["body"]


def test_anthropic_system_prompt_split_and_headers():
    seen = {}

    def h(req):
        seen["h"] = req.headers; seen["b"] = json.loads(req.content)
        return httpx.Response(200, json={"content": [{"type": "text", "text": "ok"}],
                                         "usage": {"input_tokens": 4, "output_tokens": 2}})
    r = call(adapter(AnthropicAdapter, h))
    assert r.text == "ok" and seen["b"]["system"] == "be brief"
    assert all(m["role"] != "system" for m in seen["b"]["messages"])
    assert seen["h"]["x-api-key"] == "k-123456" and "anthropic-version" in seen["h"]


def test_gemini_key_in_header_not_url():
    seen = {}

    def h(req):
        seen["url"] = str(req.url); seen["key"] = req.headers.get("x-goog-api-key")
        return httpx.Response(200, json={"candidates": [{"content": {"parts": [{"text": "g"}]}}]})
    assert call(adapter(GeminiAdapter, h)).text == "g"
    assert "k-123456" not in seen["url"] and seen["key"] == "k-123456"


def test_ollama_no_auth_header():
    def h(req):
        assert "authorization" not in req.headers
        return httpx.Response(200, json={"message": {"content": "local"}, "eval_count": 2})
    assert call(adapter(OllamaAdapter, h, key=None)).text == "local"


@pytest.mark.parametrize("status,body,exc", [
    (429, "rate", RateLimitError), (429, "insufficient_quota", QuotaExhaustedError),
    (401, "", AuthenticationError), (503, "", TransientError)])
def test_http_errors_map_to_typed_exceptions(status, body, exc):
    with pytest.raises(exc):
        call(adapter(OpenAIAdapter, lambda r: httpx.Response(status, text=body)))


def test_timeout_and_connection_errors():
    def slow(req):
        raise httpx.ReadTimeout("t", request=req)

    def down(req):
        raise httpx.ConnectError("refused", request=req)
    with pytest.raises(ProviderTimeoutError):
        call(adapter(OpenAIAdapter, slow))
    with pytest.raises(ProviderConnectionError):
        call(adapter(OllamaAdapter, down, key=None))


def test_upstream_error_body_and_key_never_in_exception():
    leak = "sk-SECRET-LEAK-123456789"
    try:
        call(adapter(OpenAIAdapter, lambda r: httpx.Response(401, text=f"bad key {leak}")))
    except AuthenticationError as e:
        assert leak not in str(e) and "k-123456" not in str(e)
