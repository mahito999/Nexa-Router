import pytest

from app.routing.classifier import classify


@pytest.mark.parametrize("text,expected", [
    ("Hello, how are you today my friend?", "general_chat"),
    ("Fix this python bug: ```def f(:\n pass```", "programming"),
    ("اكتب لي كود بايثون لقراءة ملف", "programming"),
    ("Translate this sentence to French", "translation"),
    ("ترجم هذا النص إلى الإنجليزية", "translation"),
    ("Solve the equation 3x + 2 = 11 and compute the derivative", "math"),
    ("احسب تكامل هذه الدالة", "math"),
    ("Generate an image of a red fox in the snow", "image_generation"),
    ("ارسم صورة لقطة تلعب", "image_generation"),
    ("Create a video of a rocket launch", "video_generation"),
    ("Convert this text to speech with a calm voice (tts)", "audio_generation"),
    ("Summarize this document and extract key points of the contract", "document_analysis"),
    ("لخص هذا المستند من فضلك", "document_analysis"),
    ("Write an email to my manager asking for leave", "writing"),
    ("What is the latest news about electric cars today?", "web_research"),
])
def test_task_classification(text, expected):
    assert classify(text).task == expected


def test_override_wins_and_is_validated():
    c = classify("write python code", override="writing")
    assert c.task == "writing" and c.overridden
    with pytest.raises(ValueError):
        classify("x", override="not_a_task")


def test_attached_document_biases_to_document_analysis():
    assert classify("what does section 3 say?", has_document=True).task == "document_analysis"


def test_empty_text_is_general_chat():
    assert classify("").task == "general_chat"
