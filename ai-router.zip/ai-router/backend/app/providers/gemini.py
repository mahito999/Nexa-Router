"""Google Gemini (Generative Language API) adapter."""
from __future__ import annotations

from typing import Any, Dict, List

from ..errors import ProviderError
from ..routing.types import ChatMessage, ChatResult
from .base import HttpAdapter


class GeminiAdapter(HttpAdapter):
    kind = "gemini"

    def _headers(self) -> Dict[str, str]:
        h = {"content-type": "application/json"}
        if self._api_key:
            h["x-goog-api-key"] = self._api_key   # header, never in the URL
        return h

    async def chat(self, model, messages: List[ChatMessage], *, max_tokens,
                   temperature, timeout) -> ChatResult:
        system = "\n\n".join(m.content for m in messages if m.role == "system")
        contents = [{"role": "model" if m.role == "assistant" else "user",
                     "parts": [{"text": m.content}]}
                    for m in messages if m.role in ("user", "assistant")]
        gen: Dict[str, Any] = {"maxOutputTokens": max_tokens}
        if temperature is not None:
            gen["temperature"] = temperature
        body: Dict[str, Any] = {"contents": contents, "generationConfig": gen}
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        r = await self._request("POST", f"/v1beta/models/{model}:generateContent",
                                json=body, timeout=timeout)
        data = r.json()
        cands = data.get("candidates") or []
        if not cands:
            raise ProviderError("empty or blocked response")
        parts = (cands[0].get("content") or {}).get("parts") or []
        text = "".join(p.get("text", "") for p in parts)
        u = data.get("usageMetadata") or {}
        return ChatResult(text, u.get("promptTokenCount"), u.get("candidatesTokenCount"))

    async def list_models(self, timeout: float = 15.0) -> List[str]:
        r = await self._request("GET", "/v1beta/models", timeout=timeout)
        return sorted(m["name"].split("/", 1)[-1] for m in r.json().get("models", [])
                      if "name" in m)
