"""Shared HTTP plumbing for provider adapters."""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Set

import httpx

from ..errors import (ProviderConnectionError, ProviderTimeoutError,
                      UnsupportedCapabilityError, classify_http_error)
from ..routing.types import ChatMessage, ChatResult

_QUOTA_HEADERS = {
    "requests_limit": ("x-ratelimit-limit-requests", "anthropic-ratelimit-requests-limit"),
    "requests_remaining": ("x-ratelimit-remaining-requests", "anthropic-ratelimit-requests-remaining"),
    "tokens_limit": ("x-ratelimit-limit-tokens", "anthropic-ratelimit-tokens-limit"),
    "tokens_remaining": ("x-ratelimit-remaining-tokens", "anthropic-ratelimit-tokens-remaining"),
    "reset": ("x-ratelimit-reset-requests", "anthropic-ratelimit-requests-reset"),
}


def extract_quota(headers: httpx.Headers) -> Optional[Dict[str, Any]]:
    """Only values the provider actually sent. Returns None if there are none."""
    out: Dict[str, Any] = {}
    for key, names in _QUOTA_HEADERS.items():
        for n in names:
            if n in headers:
                out[key] = headers[n]
                break
    return out or None


class HttpAdapter:
    kind = "base"
    supported_media: Set[str] = set()   # subset of {"image_gen", "tts", "stt"}

    def __init__(self, base_url: str, api_key: Optional[str],
                 client: httpx.AsyncClient) -> None:
        self.base_url = base_url.rstrip("/")
        self._api_key = api_key
        self.client = client

    # subclasses override
    def _headers(self) -> Dict[str, str]:
        return {"content-type": "application/json"}

    async def chat(self, model: str, messages: List[ChatMessage], *,
                   max_tokens: int, temperature: Optional[float],
                   timeout: float) -> ChatResult:
        raise NotImplementedError

    async def list_models(self, timeout: float = 15.0) -> List[str]:
        raise NotImplementedError

    async def _request(self, method: str, path: str, *, timeout: float,
                       json: Any = None, data: Any = None,
                       files: Any = None) -> httpx.Response:
        headers = self._headers()
        if files is not None:
            headers.pop("content-type", None)
        try:
            r = await self.client.request(method, self.base_url + path,
                                          headers=headers, json=json, data=data,
                                          files=files, timeout=timeout)
        except httpx.TimeoutException as e:
            raise ProviderTimeoutError("request timed out") from e
        except httpx.TransportError as e:
            raise ProviderConnectionError("could not connect to provider") from e
        if r.status_code >= 400:
            # body is inspected for classification only, never propagated
            raise classify_http_error(r.status_code, r.text[:2000], r.headers)
        return r

    # --- optional media API (adapters that support it override these)
    async def generate_image(self, model: str, prompt: str, *, size: Optional[str],
                             timeout: float) -> Dict[str, Any]:
        raise UnsupportedCapabilityError("image generation not supported")

    async def text_to_speech(self, model: str, text: str, *, voice: Optional[str],
                             timeout: float) -> Dict[str, Any]:
        raise UnsupportedCapabilityError("text-to-speech not supported")

    async def speech_to_text(self, model: str, audio: bytes, filename: str, *,
                             timeout: float) -> Dict[str, Any]:
        raise UnsupportedCapabilityError("speech-to-text not supported")
