"""Anthropic Messages API adapter."""
from __future__ import annotations

from typing import Any, Dict, List

from ..errors import ProviderError
from ..routing.types import ChatMessage, ChatResult
from .base import HttpAdapter, extract_quota

API_VERSION = "2023-06-01"


class AnthropicAdapter(HttpAdapter):
    kind = "anthropic"

    def _headers(self) -> Dict[str, str]:
        h = {"content-type": "application/json", "anthropic-version": API_VERSION}
        if self._api_key:
            h["x-api-key"] = self._api_key
        return h

    async def chat(self, model, messages: List[ChatMessage], *, max_tokens,
                   temperature, timeout) -> ChatResult:
        system = "\n\n".join(m.content for m in messages if m.role == "system")
        convo = [{"role": m.role, "content": m.content}
                 for m in messages if m.role in ("user", "assistant")]
        body: Dict[str, Any] = {"model": model, "max_tokens": max_tokens, "messages": convo}
        if system:
            body["system"] = system
        if temperature is not None:
            body["temperature"] = temperature
        r = await self._request("POST", "/v1/messages", json=body, timeout=timeout)
        data = r.json()
        blocks = data.get("content")
        if not isinstance(blocks, list):
            raise ProviderError("unexpected response shape")
        text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
        usage = data.get("usage") or {}
        return ChatResult(text, usage.get("input_tokens"), usage.get("output_tokens"),
                          extract_quota(r.headers))

    async def list_models(self, timeout: float = 15.0) -> List[str]:
        r = await self._request("GET", "/v1/models", timeout=timeout)
        return sorted(m["id"] for m in r.json().get("data", []) if "id" in m)
