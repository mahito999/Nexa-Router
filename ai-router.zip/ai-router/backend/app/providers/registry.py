"""Provider kind registry. Add a new provider by registering a kind; no other
code changes are needed. External plugins: set AI_ROUTER_PLUGINS=pkg.module and
call `register_kind(...)` at import time."""
from __future__ import annotations

import importlib
import re
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

import httpx

from ..routing.types import CAP_IMAGE, CAP_STT, CAP_TEXT, CAP_TTS, ModelSpec
from .anthropic import AnthropicAdapter
from .base import HttpAdapter
from .gemini import GeminiAdapter
from .ollama import OllamaAdapter
from .openai_compat import OpenAIAdapter, OpenAICompatAdapter


@dataclass
class KindTemplate:
    kind: str
    label: str
    default_base_url: Optional[str]
    default_key_env: Optional[str]
    requires_key: bool
    is_local: bool
    factory: Callable[[str, Optional[str], httpx.AsyncClient], HttpAdapter]


KINDS: Dict[str, KindTemplate] = {}


def register_kind(t: KindTemplate) -> None:
    KINDS[t.kind] = t


def _t(kind, label, url, env, req, local, cls):
    register_kind(KindTemplate(kind, label, url, env, req, local,
                               lambda b, k, c, _cls=cls: _cls(b, k, c)))


_t("openai", "OpenAI", "https://api.openai.com/v1", "OPENAI_API_KEY", True, False, OpenAIAdapter)
_t("anthropic", "Anthropic (Claude)", "https://api.anthropic.com", "ANTHROPIC_API_KEY", True, False, AnthropicAdapter)
_t("gemini", "Google Gemini", "https://generativelanguage.googleapis.com", "GEMINI_API_KEY", True, False, GeminiAdapter)
_t("openrouter", "OpenRouter", "https://openrouter.ai/api/v1", "OPENROUTER_API_KEY", True, False, OpenAICompatAdapter)
_t("ollama", "Ollama (local)", "http://localhost:11434", None, False, True, OllamaAdapter)
_t("openai_compatible", "OpenAI-compatible (custom URL)", None, None, False, False, OpenAICompatAdapter)


def load_plugins(spec: str) -> List[str]:
    loaded = []
    for name in filter(None, (s.strip() for s in (spec or "").split(","))):
        importlib.import_module(name)
        loaded.append(name)
    return loaded


def build_adapter(kind: str, base_url: str, api_key: Optional[str],
                  client: httpx.AsyncClient) -> HttpAdapter:
    return KINDS[kind].factory(base_url, api_key, client)


_IMG = re.compile(r"dall-?e|gpt-image|imagen|flux|stable-diffusion|sdxl", re.I)
_TTS = re.compile(r"tts|speech", re.I)
_STT = re.compile(r"whisper|transcribe", re.I)
_FAST = re.compile(r"mini|flash|haiku|nano|small|lite|instant|\b[1-8]b\b", re.I)
_BIG = re.compile(r"opus|sonnet|\bpro\b|large|70b|405b|\bgpt-5\b|\bo[134]\b", re.I)


def default_model_spec(name: str, is_local: bool = False) -> ModelSpec:
    """Starting values only. Scores are editable heuristics, not benchmarks, and
    media capabilities are inferred from the model name only."""
    if _IMG.search(name):
        return ModelSpec(name, {CAP_IMAGE})
    if _STT.search(name):
        return ModelSpec(name, {CAP_STT})
    if _TTS.search(name):
        return ModelSpec(name, {CAP_TTS})
    q, s = 5, 5
    if _FAST.search(name):
        q, s = 4, 8
    if _BIG.search(name):
        q, s = 8, 4
    if is_local:
        q = min(q, 5)
    return ModelSpec(name, {CAP_TEXT}, quality=q, speed=s)
