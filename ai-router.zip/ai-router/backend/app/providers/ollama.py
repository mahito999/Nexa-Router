"""Ollama (local) adapter."""
from __future__ import annotations

from typing import Any, Dict, List

from ..errors import ProviderError
from ..routing.types import ChatMessage, ChatResult
from .base import HttpAdapter


class OllamaAdapter(HttpAdapter):
    kind = "ollama"

    async def chat(self, model, messages: List[ChatMessage], *, max_tokens,
                   temperature, timeout) -> ChatResult:
        options: Dict[str, Any] = {"num_predict": max_tokens}
        if temperature is not None:
            options["temperature"] = temperature
        body = {"model": model, "stream": False, "options": options,
                "messages": [{"role": m.role, "content": m.content} for m in messages]}
        r = await self._request("POST", "/api/chat", json=body, timeout=timeout)
        data = r.json()
        msg = data.get("message")
        if not isinstance(msg, dict):
            raise ProviderError("unexpected response shape")
        return ChatResult(msg.get("content", ""), data.get("prompt_eval_count"),
                          data.get("eval_count"))

    async def list_models(self, timeout: float = 15.0) -> List[str]:
        r = await self._request("GET", "/api/tags", timeout=timeout)
        return sorted(m["name"] for m in r.json().get("models", []) if "name" in m)
