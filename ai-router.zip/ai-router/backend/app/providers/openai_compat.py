"""OpenAI and any OpenAI-compatible endpoint (OpenRouter, vLLM, LM Studio,
llama.cpp server, Together, Groq, ...)."""
from __future__ import annotations

import base64
from typing import Any, Dict, List, Optional

from ..errors import ProviderError
from ..routing.types import ChatMessage, ChatResult
from .base import HttpAdapter, extract_quota


class OpenAICompatAdapter(HttpAdapter):
    kind = "openai_compatible"
    supported_media = {"image_gen", "tts", "stt"}
    official_openai = False

    def _headers(self) -> Dict[str, str]:
        h = {"content-type": "application/json"}
        if self._api_key:
            h["authorization"] = f"Bearer {self._api_key}"
        return h

    async def chat(self, model, messages: List[ChatMessage], *, max_tokens,
                   temperature, timeout) -> ChatResult:
        body: Dict[str, Any] = {
            "model": model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
        }
        body["max_completion_tokens" if self.official_openai else "max_tokens"] = max_tokens
        if temperature is not None:
            body["temperature"] = temperature
        r = await self._request("POST", "/chat/completions", json=body, timeout=timeout)
        data = r.json()
        try:
            text = data["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError, TypeError) as e:
            raise ProviderError("unexpected response shape") from e
        usage = data.get("usage") or {}
        return ChatResult(text, usage.get("prompt_tokens"),
                          usage.get("completion_tokens"), extract_quota(r.headers))

    async def list_models(self, timeout: float = 15.0) -> List[str]:
        r = await self._request("GET", "/models", timeout=timeout)
        return sorted(m["id"] for m in r.json().get("data", []) if "id" in m)

    async def generate_image(self, model, prompt, *, size, timeout):
        body: Dict[str, Any] = {"model": model, "prompt": prompt, "n": 1}
        if size:
            body["size"] = size
        r = await self._request("POST", "/images/generations", json=body, timeout=timeout)
        items = r.json().get("data") or []
        if not items:
            raise ProviderError("provider returned no image")
        return {"url": items[0].get("url"), "b64_json": items[0].get("b64_json"),
                "mime": "image/png"}

    async def text_to_speech(self, model, text, *, voice, timeout):
        body = {"model": model, "input": text}
        if voice:
            body["voice"] = voice
        r = await self._request("POST", "/audio/speech", json=body, timeout=timeout)
        return {"audio_base64": base64.b64encode(r.content).decode(),
                "mime": r.headers.get("content-type", "audio/mpeg")}

    async def speech_to_text(self, model, audio, filename, *, timeout):
        r = await self._request("POST", "/audio/transcriptions", timeout=timeout,
                                data={"model": model},
                                files={"file": (filename, audio)})
        return {"text": r.json().get("text", "")}


class OpenAIAdapter(OpenAICompatAdapter):
    kind = "openai"
    official_openai = True
