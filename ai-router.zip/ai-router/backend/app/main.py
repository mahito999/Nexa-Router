"""FastAPI application: REST API + (optionally) the built frontend."""
from __future__ import annotations

import base64
import json
import logging
import os
import uuid
from typing import Any, Dict, List, Literal, Optional

import httpx
from fastapi import APIRouter, Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select

from . import security
from .config import Settings
from .db import ConversationRow, MessageRow, ProviderRow, UsageRow, utcnow
from .errors import (AllProvidersFailedError, NoEligibleModelError,
                     ProviderError, RequestRejectedError)
from .providers import registry
from .routing.classifier import TASKS, classify
from .routing.types import MODES, TASK_CAPABILITY, ChatMessage
from .service import AppState, model_from_dict, model_to_dict

log = logging.getLogger("ai_router")

CAPS = ["text", "web_search", "image_gen", "video_gen", "tts", "stt"]
ID_RE = r"^[a-z0-9][a-z0-9_-]{1,40}$"


# ---------------------------------------------------------------- schemas
class ModelIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    capabilities: List[Literal["text", "web_search", "image_gen", "video_gen", "tts", "stt"]] = ["text"]
    quality: int = Field(5, ge=1, le=10)
    speed: int = Field(5, ge=1, le=10)
    free: bool = False
    strengths: List[str] = []
    price_in: Optional[float] = Field(None, ge=0)
    price_out: Optional[float] = Field(None, ge=0)

    @field_validator("strengths")
    @classmethod
    def _strengths(cls, v):
        bad = [t for t in v if t not in TASKS]
        if bad:
            raise ValueError(f"unknown task categories: {bad}")
        return v


class ProviderIn(BaseModel):
    id: str = Field(pattern=ID_RE)
    name: str = Field(min_length=1, max_length=120)
    kind: str
    base_url: Optional[str] = None
    api_key: Optional[str] = Field(None, max_length=1024, repr=False)  # write-only
    api_key_env: Optional[str] = Field(None, pattern=r"^[A-Z_][A-Z0-9_]{0,79}$")
    enabled: bool = True
    priority: int = Field(100, ge=0, le=10000)
    is_local: Optional[bool] = None
    models: List[ModelIn] = []


class ProviderPatch(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=120)
    base_url: Optional[str] = None
    api_key: Optional[str] = Field(None, max_length=1024, repr=False)  # "" clears
    api_key_env: Optional[str] = Field(None, pattern=r"^([A-Z_][A-Z0-9_]{0,79})?$")
    enabled: Optional[bool] = None
    priority: Optional[int] = Field(None, ge=0, le=10000)
    is_local: Optional[bool] = None
    models: Optional[List[ModelIn]] = None


class ChatIn(BaseModel):
    message: str = Field(min_length=1)
    conversation_id: Optional[int] = None
    mode: Literal["auto", "fast", "best", "free_first"] = "auto"
    task: Optional[str] = None
    document_text: Optional[str] = Field(None, max_length=200_000)
    max_tokens: int = Field(1024, ge=1, le=8192)
    temperature: Optional[float] = Field(None, ge=0, le=2)


class CompareIn(BaseModel):
    message: str = Field(min_length=1)
    task: Optional[str] = None
    count: int = Field(3, ge=2, le=6)
    max_tokens: int = Field(1024, ge=1, le=8192)


class RoutingIn(BaseModel):
    default_mode: Literal["auto", "fast", "best", "free_first", "compare"] = "auto"
    max_total_attempts: int = Field(6, ge=1, le=12)
    transient_retries: int = Field(1, ge=0, le=3)
    request_timeout: float = Field(60.0, ge=5, le=600)
    compare_count: int = Field(3, ge=2, le=6)
    strict_fallback_order: bool = False
    fallback_order: List[str] = []


class SystemIn(BaseModel):
    default_language: Literal["ar", "en"] = "ar"
    max_context_messages: int = Field(20, ge=2, le=100)
    user_daily_request_limit: Optional[int] = Field(None, ge=0)
    user_daily_token_limit: Optional[int] = Field(None, ge=0)


class ImageIn(BaseModel):
    prompt: str = Field(min_length=1, max_length=4000)
    size: Optional[str] = Field(None, pattern=r"^\d{3,4}x\d{3,4}$")


class TTSIn(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    voice: Optional[str] = Field(None, max_length=60)


class STTIn(BaseModel):
    audio_base64: str = Field(min_length=1, max_length=40_000_000)
    filename: str = Field("audio.mp3", pattern=r"^[\w.\-]{1,100}$")


class RenameIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)


# ------------------------------------------------------------------- app
def create_app(settings: Optional[Settings] = None,
               transport: Optional[httpx.AsyncBaseTransport] = None) -> FastAPI:
    settings = settings or Settings.from_env()
    logging.basicConfig(level=settings.log_level)
    security.install_log_redaction()
    state = AppState(settings, transport)
    app = FastAPI(title="AI Router", version="0.1.0-alpha")
    app.state.ai = state
    if settings.cors_origins:
        app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins,
                           allow_methods=["*"], allow_headers=["*"])

    # -------- secure error handling: no internals, no upstream bodies
    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception):
        rid = uuid.uuid4().hex[:8]
        log.error("unhandled error rid=%s type=%s", rid, type(exc).__name__)
        return JSONResponse({"detail": {"code": "internal_error", "request_id": rid,
                                        "message": "Internal server error"}}, status_code=500)

    @app.exception_handler(RequestValidationError)
    async def _invalid(request: Request, exc: RequestValidationError):
        errs = [{"field": ".".join(str(p) for p in e["loc"][1:]), "message": e["msg"]}
                for e in exc.errors()]
        return JSONResponse({"detail": {"code": "invalid_request", "errors": errs}}, status_code=422)

    # -------- dependencies
    def current_user(request: Request) -> security.User:
        if state.tokens:
            user = security.authenticate(state.tokens, request.headers.get("authorization"))
            if user is None:
                raise HTTPException(401, {"code": "unauthorized", "message": "Valid bearer token required"})
        else:
            user = security.User("local", "admin")
        key = f"{user.id}"
        if not state.limiter.allow(key):
            raise HTTPException(429, {"code": "rate_limited", "message": "Too many requests"})
        state._current_user = user.id
        return user

    def admin(user: security.User = Depends(current_user)) -> security.User:
        if not user.is_admin:
            raise HTTPException(403, {"code": "forbidden", "message": "Administrator role required"})
        return user

    api = APIRouter(prefix="/api")

    @app.get("/healthz")
    def healthz():
        return {"status": "ok"}

    # -------- meta
    @api.get("/meta")
    def meta(user: security.User = Depends(current_user)):
        return {"auth_enabled": bool(state.tokens), "user": {"id": user.id, "role": user.role},
                "modes": MODES, "tasks": TASKS, "capabilities": CAPS,
                "kinds": [{"kind": t.kind, "label": t.label, "default_base_url": t.default_base_url,
                           "default_key_env": t.default_key_env, "requires_key": t.requires_key,
                           "is_local": t.is_local} for t in registry.KINDS.values()],
                "system": state.system_settings()}

    # -------- providers
    def provider_out(row: ProviderRow) -> Dict[str, Any]:
        return {"id": row.id, "name": row.name, "kind": row.kind, "base_url": row.base_url,
                "api_key_env": row.api_key_env, "key_source": state.key_source(row),
                "enabled": row.enabled, "priority": row.priority, "is_local": row.is_local,
                "status": state.provider_status(row),
                "models": json.loads(row.models_json or "[]")}   # api key never included

    def check_url(url: str) -> str:
        try:
            return security.validate_base_url(url)
        except ValueError as e:
            raise HTTPException(422, {"code": "invalid_base_url", "message": str(e)})

    @api.get("/providers")
    def list_providers(user: security.User = Depends(current_user)):
        with state.Session() as s:
            return [provider_out(r) for r in s.scalars(
                select(ProviderRow).order_by(ProviderRow.priority, ProviderRow.id))]

    @api.post("/providers", status_code=201)
    def create_provider(body: ProviderIn, user: security.User = Depends(admin)):
        tpl = registry.KINDS.get(body.kind)
        if tpl is None:
            raise HTTPException(422, {"code": "unknown_kind", "message": f"unknown provider kind: {body.kind}"})
        base = body.base_url or tpl.default_base_url
        if not base:
            raise HTTPException(422, {"code": "base_url_required", "message": "base_url is required for this kind"})
        base = check_url(base)
        models = body.models or []
        with state.Session() as s:
            if s.get(ProviderRow, body.id):
                raise HTTPException(409, {"code": "exists", "message": "provider id already exists"})
            row = ProviderRow(
                id=body.id, name=body.name, kind=body.kind, base_url=base,
                api_key_enc=state.box.encrypt(body.api_key) if body.api_key else None,
                api_key_env=body.api_key_env or tpl.default_key_env, enabled=body.enabled,
                priority=body.priority,
                is_local=tpl.is_local if body.is_local is None else body.is_local,
                models_json=json.dumps([m.model_dump() for m in models]))
            s.add(row); s.commit()
            security.register_secret(body.api_key)
            return provider_out(row)

    @api.patch("/providers/{pid}")
    def update_provider(pid: str, body: ProviderPatch, user: security.User = Depends(admin)):
        with state.Session() as s:
            row = s.get(ProviderRow, pid)
            if not row:
                raise HTTPException(404, {"code": "not_found", "message": "provider not found"})
            d = body.model_dump(exclude_unset=True)
            if "base_url" in d and d["base_url"]:
                row.base_url = check_url(d["base_url"])
            if "api_key" in d:
                row.api_key_enc = state.box.encrypt(d["api_key"]) if d["api_key"] else None
                security.register_secret(d["api_key"])
            for k in ("name", "enabled", "priority", "is_local"):
                if k in d and d[k] is not None:
                    setattr(row, k, d[k])
            if "api_key_env" in d:
                row.api_key_env = d["api_key_env"] or None
            if d.get("models") is not None:
                row.models_json = json.dumps(d["models"])
            s.commit()
            state.health.reset(pid)     # config changed: clear parked/cooldown state
            return provider_out(row)

    @api.delete("/providers/{pid}", status_code=204)
    def delete_provider(pid: str, user: security.User = Depends(admin)):
        with state.Session() as s:
            row = s.get(ProviderRow, pid)
            if not row:
                raise HTTPException(404, {"code": "not_found", "message": "provider not found"})
            s.delete(row); s.commit()

    def runtime(pid: str):
        for r in state.runtimes():
            if r.id == pid:
                return r
        raise HTTPException(404, {"code": "not_found", "message": "provider not found"})

    @api.post("/providers/{pid}/test")
    async def test_provider(pid: str, user: security.User = Depends(admin)):
        rt = runtime(pid)
        with state.Session() as s:
            row = s.get(ProviderRow, pid)
            status = state.provider_status(row)
        if status == "missing_key":
            return {"ok": False, "error_type": "missing_key",
                    "message": "No API key configured (set a key or its environment variable)."}
        try:
            names = await rt.adapter.list_models(timeout=15)
        except ProviderError as e:
            if e.permanent:
                state.health._auth_failed[pid] = e.kind
            return {"ok": False, "error_type": e.kind, "http_status": e.status}
        state.health.reset(pid)
        return {"ok": True, "models_found": len(names)}

    @api.get("/providers/{pid}/discover-models")
    async def discover(pid: str, user: security.User = Depends(admin)):
        rt = runtime(pid)
        try:
            names = await rt.adapter.list_models(timeout=20)
        except ProviderError as e:
            raise HTTPException(502, {"code": e.kind, "message": "could not list models"})
        with state.Session() as s:
            local = s.get(ProviderRow, pid).is_local
        return [model_to_dict(registry.default_model_spec(n, local)) for n in names]

    # -------- model explorer
    @api.get("/models")
    def models(user: security.User = Depends(current_user)):
        out = []
        for rt in state.runtimes():
            for m in rt.models:
                reason = state.health.unavailable_reason(rt.id, m.name)
                out.append({**model_to_dict(m), "provider_id": rt.id, "provider_kind": rt.kind,
                            "local": rt.is_local,
                            "available": rt.enabled and reason is None,
                            "unavailable_reason": "provider_disabled_or_missing_key" if not rt.enabled else reason})
        return out

    @api.get("/capabilities")
    def capabilities(user: security.User = Depends(current_user)):
        res = {}
        for task, cap in TASK_CAPABILITY.items():
            plan = state.router.plan(task, "auto")
            res[task] = {"available": bool(plan.candidates),
                         "models": [c.label for c in plan.candidates]}
        return res

    # -------- routing / system settings
    @api.get("/routing")
    def get_routing(user: security.User = Depends(current_user)):
        r = state.router.settings
        return {k: getattr(r, k) for k in RoutingIn.model_fields}

    @api.put("/routing")
    def put_routing(body: RoutingIn, user: security.User = Depends(admin)):
        state.kv_set("routing", body.model_dump())
        state.router.settings = state.load_routing()
        return body

    @api.get("/system")
    def get_system(user: security.User = Depends(current_user)):
        return state.system_settings()

    @api.put("/system")
    def put_system(body: SystemIn, user: security.User = Depends(admin)):
        state.kv_set("system", body.model_dump())
        return state.system_settings()

    # -------- chat
    def fail(exc: Exception):
        if isinstance(exc, NoEligibleModelError):
            return HTTPException(503, {"code": "no_eligible_model", "message": str(exc),
                                       "skipped": exc.skipped})
        if isinstance(exc, AllProvidersFailedError):
            return HTTPException(502, {"code": "all_providers_failed",
                                       "message": "Every eligible provider failed", "attempts": exc.attempts})
        if isinstance(exc, RequestRejectedError):
            return HTTPException(400, {"code": "request_rejected",
                                       "message": "The provider rejected the request", "attempts": exc.attempts})
        raise exc

    def check_text(text: str) -> None:
        if len(text) > settings.max_message_chars:
            raise HTTPException(413, {"code": "message_too_long",
                                      "message": f"max {settings.max_message_chars} characters"})

    def classification(message: str, task: Optional[str], has_doc: bool):
        try:
            return classify(message, override=task, has_document=has_doc)
        except ValueError:
            raise HTTPException(422, {"code": "unknown_task", "message": f"task must be one of {TASKS}"})

    @api.post("/route/preview")
    def preview(body: ChatIn, user: security.User = Depends(current_user)):
        c = classification(body.message, body.task, bool(body.document_text))
        plan = state.router.plan(c.task, body.mode)
        return {"task": c.task, "confidence": c.confidence, "signals": c.signals[:8],
                "candidates": [{"provider": x.provider.id, "model": x.model.name,
                                "score": round(x.score, 1)} for x in plan.candidates],
                "skipped": plan.skipped, "warnings": plan.warnings}

    @api.post("/chat")
    async def chat(body: ChatIn, user: security.User = Depends(current_user)):
        check_text(body.message)
        limit = state.check_user_limits(user.id)
        if limit:
            raise HTTPException(429, {"code": limit, "message": "Usage limit reached for today"})
        sysd = state.system_settings()
        c = classification(body.message, body.task, bool(body.document_text))
        with state.Session() as s:
            if body.conversation_id:
                conv = s.get(ConversationRow, body.conversation_id)
                if not conv or conv.user_id != user.id:
                    raise HTTPException(404, {"code": "not_found", "message": "conversation not found"})
            else:
                conv = ConversationRow(user_id=user.id, title=body.message[:60])
                s.add(conv); s.flush()
            hist = [ChatMessage(m.role, m.content) for m in conv.messages][-sysd["max_context_messages"]:]
            content = body.message if not body.document_text else \
                f"{body.message}\n\n--- document ---\n{body.document_text}"
            msgs = hist + [ChatMessage("user", content)]
            try:
                out = await state.router.chat(msgs, c.task, body.mode,
                                              max_tokens=body.max_tokens, temperature=body.temperature)
            except (NoEligibleModelError, AllProvidersFailedError, RequestRejectedError) as e:
                s.rollback()
                raise fail(e)
            s.add(MessageRow(conversation_id=conv.id, role="user", content=body.message, task=c.task))
            s.add(MessageRow(conversation_id=conv.id, role="assistant", content=out.content,
                             provider_id=out.provider_id, model=out.model, task=c.task))
            conv.updated_at = utcnow()
            s.commit()
            cid = conv.id
        return {"conversation_id": cid, "content": out.content, "provider": out.provider_id,
                "model": out.model, "task": c.task,
                "classification": {"confidence": c.confidence, "overridden": c.overridden},
                "mode": body.mode, "fallback_used": out.fallback_used, "attempts": out.attempts,
                "warnings": out.warnings,
                "tokens": {"prompt": out.prompt_tokens, "completion": out.completion_tokens}}

    @api.post("/compare")
    async def compare(body: CompareIn, user: security.User = Depends(current_user)):
        check_text(body.message)
        limit = state.check_user_limits(user.id)
        if limit:
            raise HTTPException(429, {"code": limit, "message": "Usage limit reached for today"})
        c = classification(body.message, body.task, False)
        try:
            res = await state.router.compare([ChatMessage("user", body.message)], c.task,
                                             max_tokens=body.max_tokens, count=body.count)
        except NoEligibleModelError as e:
            raise fail(e)
        return {"task": c.task, "results": res}

    # -------- media (only when a capable provider is configured)
    async def media(task: str, call):
        plan = state.router.plan(task, "auto")
        if not plan.candidates:
            raise HTTPException(409, {"code": "no_provider_configured", "task": task,
                                      "message": "No configured provider supports this capability."})
        try:
            cand, res, attempts = await state.router.execute(plan, call)
        except (NoEligibleModelError, AllProvidersFailedError, RequestRejectedError) as e:
            raise fail(e)
        return {"provider": cand.provider.id, "model": cand.model.name,
                "attempts": attempts, "result": res}

    @api.post("/media/image")
    async def image(body: ImageIn, user: security.User = Depends(current_user)):
        t = state.router.settings.request_timeout
        return await media("image_generation", lambda c: c.provider.adapter.generate_image(
            c.model.name, body.prompt, size=body.size, timeout=t))

    @api.post("/media/tts")
    async def tts(body: TTSIn, user: security.User = Depends(current_user)):
        t = state.router.settings.request_timeout
        return await media("audio_generation", lambda c: c.provider.adapter.text_to_speech(
            c.model.name, body.text, voice=body.voice, timeout=t))

    @api.post("/media/stt")
    async def stt(body: STTIn, user: security.User = Depends(current_user)):
        try:
            audio = base64.b64decode(body.audio_base64, validate=True)
        except Exception:
            raise HTTPException(422, {"code": "invalid_audio", "message": "audio_base64 is not valid base64"})
        plan = state.router.plan("general_chat", "auto")  # placeholder to reuse health logic
        cands, skipped = state.router._collect("stt", "audio")
        if not cands:
            raise HTTPException(409, {"code": "no_provider_configured", "task": "speech_to_text",
                                      "message": "No configured provider supports speech-to-text."})
        plan.candidates = state.router._order(cands, "audio", "auto")
        t = state.router.settings.request_timeout
        try:
            cand, res, attempts = await state.router.execute(
                plan, lambda c: c.provider.adapter.speech_to_text(c.model.name, audio, body.filename, timeout=t))
        except (NoEligibleModelError, AllProvidersFailedError, RequestRejectedError) as e:
            raise fail(e)
        return {"provider": cand.provider.id, "model": cand.model.name, "result": res}

    # -------- usage
    @api.get("/usage")
    def usage(user: security.User = Depends(current_user)):
        return state.usage_summary()

    @api.get("/usage/recent")
    def usage_recent(limit: int = 50, user: security.User = Depends(current_user)):
        with state.Session() as s:
            q = select(UsageRow).order_by(UsageRow.id.desc()).limit(min(max(limit, 1), 200))
            if state.tokens and not user.is_admin:
                q = q.where(UsageRow.user_id == user.id)
            return [{"ts": r.ts.isoformat(), "provider": r.provider_id, "model": r.model,
                     "task": r.task, "mode": r.mode, "success": r.success,
                     "error_type": r.error_type, "latency_ms": r.latency_ms}
                    for r in s.scalars(q)]

    # -------- conversations
    @api.get("/conversations")
    def conversations(user: security.User = Depends(current_user)):
        with state.Session() as s:
            rows = s.scalars(select(ConversationRow).where(ConversationRow.user_id == user.id)
                             .order_by(ConversationRow.updated_at.desc()).limit(200))
            return [{"id": r.id, "title": r.title, "updated_at": r.updated_at.isoformat()} for r in rows]

    def own_conv(s, cid: int, user: security.User) -> ConversationRow:
        conv = s.get(ConversationRow, cid)
        if not conv or conv.user_id != user.id:
            raise HTTPException(404, {"code": "not_found", "message": "conversation not found"})
        return conv

    @api.get("/conversations/{cid}")
    def conversation(cid: int, user: security.User = Depends(current_user)):
        with state.Session() as s:
            conv = own_conv(s, cid, user)
            return {"id": conv.id, "title": conv.title,
                    "messages": [{"role": m.role, "content": m.content, "provider": m.provider_id,
                                  "model": m.model, "task": m.task} for m in conv.messages]}

    @api.patch("/conversations/{cid}")
    def rename(cid: int, body: RenameIn, user: security.User = Depends(current_user)):
        with state.Session() as s:
            own_conv(s, cid, user).title = body.title
            s.commit()
        return {"id": cid, "title": body.title}

    @api.delete("/conversations/{cid}", status_code=204)
    def delete_conversation(cid: int, user: security.User = Depends(current_user)):
        with state.Session() as s:
            s.delete(own_conv(s, cid, user)); s.commit()

    app.include_router(api)

    dist = os.path.abspath(settings.frontend_dist)
    if os.path.isdir(dist):
        app.mount("/", StaticFiles(directory=dist, html=True), name="frontend")

    @app.on_event("shutdown")
    async def _close():
        await state.client.aclose()

    return app


def get_app() -> FastAPI:          # uvicorn app.main:get_app --factory
    return create_app()
