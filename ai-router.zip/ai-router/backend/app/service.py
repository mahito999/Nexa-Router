"""Application service layer: DB <-> router glue."""
from __future__ import annotations

import datetime as dt
import json
import os
from typing import Any, Dict, List, Optional

import httpx
from sqlalchemy import case, func, select

from . import security
from .config import Settings
from .db import (ConversationRow, KVRow, MessageRow, ProviderRow, UsageRow,
                 make_engine, make_session_factory, utcnow)
from .providers import registry
from .routing.router import HealthTracker, Router
from .routing.types import ModelSpec, ProviderRuntime, RoutingSettings

SYSTEM_DEFAULTS = {"default_language": "ar", "max_context_messages": 20,
                   "user_daily_request_limit": None, "user_daily_token_limit": None}


def model_to_dict(m: ModelSpec) -> Dict[str, Any]:
    return {"name": m.name, "capabilities": sorted(m.capabilities), "quality": m.quality,
            "speed": m.speed, "free": m.free, "strengths": sorted(m.strengths),
            "price_in": m.price_in, "price_out": m.price_out}


def model_from_dict(d: Dict[str, Any]) -> ModelSpec:
    return ModelSpec(d["name"], set(d.get("capabilities") or ["text"]),
                     int(d.get("quality", 5)), int(d.get("speed", 5)),
                     bool(d.get("free", False)), set(d.get("strengths") or []),
                     d.get("price_in"), d.get("price_out"))


class AppState:
    def __init__(self, settings: Settings,
                 transport: Optional[httpx.AsyncBaseTransport] = None) -> None:
        self.settings = settings
        os.makedirs(settings.data_dir, exist_ok=True)
        self.engine = make_engine(settings.database_url)
        self.Session = make_session_factory(self.engine)
        self.box = security.SecretBox.load_or_create(
            settings.secret_key or None, os.path.join(settings.data_dir, ".secret_key"))
        self.tokens = security.parse_tokens(settings.api_tokens)
        self.client = httpx.AsyncClient(transport=transport, follow_redirects=False)
        self.limiter = security.RateLimiter(settings.rate_limit_per_minute)
        self.health = HealthTracker()
        registry.load_plugins(settings.plugins)
        self.router = Router(self.runtimes, health=self.health,
                             settings=self.load_routing(), usage_sink=self._sink)
        self._current_user = "local"   # set per-request by the API layer

    # ---------------------------------------------------------------- kv
    def kv_get(self, key: str, default: Any) -> Any:
        with self.Session() as s:
            row = s.get(KVRow, key)
            return json.loads(row.value) if row else default

    def kv_set(self, key: str, value: Any) -> None:
        with self.Session() as s:
            row = s.get(KVRow, key)
            if row:
                row.value = json.dumps(value)
            else:
                s.add(KVRow(key=key, value=json.dumps(value)))
            s.commit()

    def load_routing(self) -> RoutingSettings:
        d = self.kv_get("routing", {})
        return RoutingSettings(**{k: v for k, v in d.items()
                                  if k in RoutingSettings.__dataclass_fields__})

    def system_settings(self) -> Dict[str, Any]:
        return {**SYSTEM_DEFAULTS, **self.kv_get("system", {})}

    # ------------------------------------------------------------ providers
    def resolve_key(self, row: ProviderRow) -> Optional[str]:
        key = None
        if row.api_key_env:
            key = os.environ.get(row.api_key_env) or None
        if not key and row.api_key_enc:
            key = self.box.decrypt(row.api_key_enc)
        security.register_secret(key)
        return key

    def key_source(self, row: ProviderRow) -> str:
        if row.api_key_env and os.environ.get(row.api_key_env):
            return "env"
        if row.api_key_enc and self.box.decrypt(row.api_key_enc):
            return "stored"
        return "none"

    def provider_status(self, row: ProviderRow) -> str:
        tpl = registry.KINDS.get(row.kind)
        if not row.enabled:
            return "disabled"
        if tpl and tpl.requires_key and self.key_source(row) == "none":
            return "missing_key"
        return self.health.status(row.id)

    def runtimes(self) -> List[ProviderRuntime]:
        out: List[ProviderRuntime] = []
        with self.Session() as s:
            rows = s.scalars(select(ProviderRow)).all()
        for row in rows:
            tpl = registry.KINDS.get(row.kind)
            if tpl is None:
                continue
            usable = row.enabled and not (tpl.requires_key and self.key_source(row) == "none")
            adapter = registry.build_adapter(row.kind, row.base_url,
                                             self.resolve_key(row), self.client)
            models = []
            for d in json.loads(row.models_json or "[]"):
                m = model_from_dict(d)
                # Never offer a media capability the adapter cannot perform.
                # (video_gen has no built-in adapter, so it is never offered.)
                allowed = {"text", "web_search"} | set(adapter.supported_media)
                m.capabilities = m.capabilities & allowed
                if m.capabilities:
                    models.append(m)
            out.append(ProviderRuntime(row.id, row.kind, adapter, models,
                                       row.priority, usable, row.is_local))
        return out

    # ---------------------------------------------------------------- usage
    def _sink(self, ev: Dict[str, Any]) -> None:
        cost = None
        pi, po = ev.get("price_in"), ev.get("price_out")
        if pi is not None and po is not None and ev.get("prompt_tokens") is not None \
                and ev.get("completion_tokens") is not None:
            cost = (ev["prompt_tokens"] * pi + ev["completion_tokens"] * po) / 1_000_000
        with self.Session() as s:
            s.add(UsageRow(user_id=self._current_user, provider_id=ev["provider_id"],
                           model=ev["model"], task=ev["task"], mode=ev["mode"],
                           success=ev["success"], error_type=ev["error_type"],
                           latency_ms=ev["latency_ms"],
                           prompt_tokens=ev.get("prompt_tokens"),
                           completion_tokens=ev.get("completion_tokens"), est_cost=cost))
            s.commit()

    def check_user_limits(self, user_id: str) -> Optional[str]:
        sysd = self.system_settings()
        req_lim = sysd["user_daily_request_limit"]
        tok_lim = sysd["user_daily_token_limit"]
        req_lim = self.settings.user_daily_request_limit if req_lim is None else req_lim
        tok_lim = self.settings.user_daily_token_limit if tok_lim is None else tok_lim
        if not req_lim and not tok_lim:
            return None
        since = utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        with self.Session() as s:
            n, toks = s.execute(
                select(func.count(UsageRow.id),
                       func.coalesce(func.sum(func.coalesce(UsageRow.prompt_tokens, 0)
                                              + func.coalesce(UsageRow.completion_tokens, 0)), 0))
                .where(UsageRow.user_id == user_id, UsageRow.ts >= since,
                       UsageRow.success.is_(True))).one()
        if req_lim and n >= req_lim:
            return "daily_request_limit_reached"
        if tok_lim and toks >= tok_lim:
            return "daily_token_limit_reached"
        return None

    def usage_summary(self) -> Dict[str, Any]:
        providers = []
        with self.Session() as s:
            rows = s.scalars(select(ProviderRow)).all()
            for row in rows:
                u = s.execute(select(
                    func.count(UsageRow.id),
                    func.sum(case((UsageRow.success.is_(True), 1), else_=0)),
                    func.coalesce(func.sum(UsageRow.prompt_tokens), 0),
                    func.coalesce(func.sum(UsageRow.completion_tokens), 0),
                    func.sum(UsageRow.est_cost),
                    func.max(UsageRow.ts).filter(UsageRow.success.is_(True)),
                ).where(UsageRow.provider_id == row.id)).one()
                errs = dict(s.execute(
                    select(UsageRow.error_type, func.count(UsageRow.id))
                    .where(UsageRow.provider_id == row.id, UsageRow.success.is_(False))
                    .group_by(UsageRow.error_type)).all())
                total, ok = u[0] or 0, int(u[1] or 0)
                reported = self.health.reported_quota.get(row.id)
                providers.append({
                    "id": row.id, "name": row.name, "status": self.provider_status(row),
                    "requests": total, "successful": ok, "failed": total - ok,
                    "errors_by_type": errs,
                    "prompt_tokens": int(u[2]), "completion_tokens": int(u[3]),
                    "tokens_source": "provider_reported_in_responses",
                    "est_cost_usd": float(u[4]) if u[4] is not None else None,
                    "last_success": u[5].isoformat() if u[5] else None,
                    "quota": {"status": "provider_reported" if reported else "unknown",
                              "provider_reported": reported,
                              "note": "Locally counted usage is not the provider's quota."},
                })
        return {"providers": providers}

