"""Environment-driven configuration. Nothing here has a secret default."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import List


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


@dataclass
class Settings:
    database_url: str = "sqlite:///./data/ai_router.db"
    data_dir: str = "./data"
    secret_key: str = ""            # Fernet key; auto-generated into data_dir if empty
    api_tokens: str = ""            # "token:user[:role],..."; empty = auth disabled
    cors_origins: List[str] = field(default_factory=list)
    rate_limit_per_minute: int = 60
    user_daily_request_limit: int = 0   # 0 = unlimited
    user_daily_token_limit: int = 0
    max_message_chars: int = 20000
    frontend_dist: str = "../frontend/dist"
    plugins: str = ""
    log_level: str = "INFO"

    @classmethod
    def from_env(cls) -> "Settings":
        e = os.environ.get
        return cls(
            database_url=e("DATABASE_URL", cls.database_url),
            data_dir=e("DATA_DIR", cls.data_dir),
            secret_key=e("APP_SECRET_KEY", ""),
            api_tokens=e("AI_ROUTER_API_TOKENS", ""),
            cors_origins=[o.strip() for o in e("CORS_ORIGINS", "").split(",") if o.strip()],
            rate_limit_per_minute=_int("RATE_LIMIT_PER_MINUTE", 60),
            user_daily_request_limit=_int("USER_DAILY_REQUEST_LIMIT", 0),
            user_daily_token_limit=_int("USER_DAILY_TOKEN_LIMIT", 0),
            max_message_chars=_int("MAX_MESSAGE_CHARS", 20000),
            frontend_dist=e("FRONTEND_DIST", cls.frontend_dist),
            plugins=e("AI_ROUTER_PLUGINS", ""),
            log_level=e("LOG_LEVEL", "INFO"),
        )
