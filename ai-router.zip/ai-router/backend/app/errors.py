"""Provider error taxonomy and HTTP error classification.

Every adapter converts transport/HTTP failures into one of these classes so the
router can decide, without provider-specific knowledge, whether to retry the
same model, fail over to another one, or stop.
"""
from __future__ import annotations

import re
from typing import Mapping, Optional


class ProviderError(Exception):
    """Base class. Attributes drive router behaviour."""

    kind = "provider_error"
    failover = True      # try the next candidate afterwards
    retry_same = False   # worth one bounded retry on the same model
    permanent = False    # provider unusable until configuration changes
    default_cooldown = 0.0

    def __init__(self, message: str = "", *, status: Optional[int] = None,
                 retry_after: Optional[float] = None) -> None:
        super().__init__(message or self.kind)
        self.status = status
        self.retry_after = retry_after

    @property
    def cooldown(self) -> float:
        return self.retry_after if self.retry_after else self.default_cooldown


class RateLimitError(ProviderError):
    kind = "rate_limit"
    default_cooldown = 30.0


class QuotaExhaustedError(ProviderError):
    kind = "quota_exhausted"
    default_cooldown = 900.0


class AuthenticationError(ProviderError):
    kind = "authentication"
    permanent = True  # never retried; provider parked until config changes


class ModelNotFoundError(ProviderError):
    kind = "model_not_found"
    default_cooldown = 600.0


class TransientError(ProviderError):
    kind = "transient"
    retry_same = True
    default_cooldown = 20.0


class ProviderTimeoutError(TransientError):
    kind = "timeout"


class ProviderConnectionError(TransientError):
    kind = "connection"
    default_cooldown = 30.0


class InvalidRequestError(ProviderError):
    """The request itself is wrong; another provider will not help."""

    kind = "invalid_request"
    failover = False


class UnsupportedCapabilityError(ProviderError):
    kind = "unsupported"


class NoEligibleModelError(Exception):
    def __init__(self, message: str, skipped: Optional[list] = None) -> None:
        super().__init__(message)
        self.skipped = skipped or []


class AllProvidersFailedError(Exception):
    def __init__(self, attempts: list) -> None:
        super().__init__("all eligible providers failed")
        self.attempts = attempts


class RequestRejectedError(Exception):
    def __init__(self, cause: ProviderError, attempts: list) -> None:
        super().__init__(str(cause))
        self.cause = cause
        self.attempts = attempts


_QUOTA = re.compile(
    r"insufficient_quota|exceeded your current quota|quota|credit balance|"
    r"out of credits|billing|resource_exhausted|payment required", re.I)
_AUTH = re.compile(r"api key not valid|api_key_invalid|invalid[_ ]api[_ ]key|"
                   r"invalid x-api-key|incorrect api key|unauthorized", re.I)


def parse_retry_after(headers: Optional[Mapping[str, str]]) -> Optional[float]:
    if not headers:
        return None
    raw = {k.lower(): v for k, v in headers.items()}.get("retry-after")
    try:
        return max(0.0, float(raw)) if raw is not None else None
    except ValueError:
        return None


def classify_http_error(status: int, body: str = "",
                        headers: Optional[Mapping[str, str]] = None) -> ProviderError:
    """Map an HTTP failure to a ProviderError. Body is only used for matching."""
    retry_after = parse_retry_after(headers)
    msg = f"HTTP {status}"
    if status == 429:
        if _QUOTA.search(body or ""):
            return QuotaExhaustedError(msg, status=status, retry_after=retry_after)
        return RateLimitError(msg, status=status, retry_after=retry_after)
    if status == 402:
        return QuotaExhaustedError(msg, status=status)
    if status in (401, 403) or (status == 400 and _AUTH.search(body or "")):
        if status == 403 and _QUOTA.search(body or ""):
            return QuotaExhaustedError(msg, status=status)
        return AuthenticationError(msg, status=status)
    if status == 404:
        return ModelNotFoundError(msg, status=status)
    if status in (400, 422):
        if _QUOTA.search(body or ""):  # e.g. "credit balance is too low"
            return QuotaExhaustedError(msg, status=status)
        return InvalidRequestError(msg, status=status)
    if status in (408, 409, 425) or status >= 500:  # includes 529 "overloaded"
        return TransientError(msg, status=status, retry_after=retry_after)
    return ProviderError(msg, status=status)
