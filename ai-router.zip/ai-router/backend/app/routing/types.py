"""Plain dataclasses shared by the router, adapters and API layer."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol, Set

# Capability vocabulary. Nothing is assumed: a model only has the capabilities
# that were configured for it (or inferred by the explicit hints table).
CAP_TEXT = "text"
CAP_WEB = "web_search"
CAP_IMAGE = "image_gen"
CAP_VIDEO = "video_gen"
CAP_TTS = "tts"
CAP_STT = "stt"

TASK_CAPABILITY = {
    "general_chat": CAP_TEXT, "programming": CAP_TEXT, "writing": CAP_TEXT,
    "translation": CAP_TEXT, "document_analysis": CAP_TEXT, "math": CAP_TEXT,
    "web_research": CAP_WEB,       # falls back to text with a warning
    "image_generation": CAP_IMAGE,
    "video_generation": CAP_VIDEO,
    "audio_generation": CAP_TTS,
}

MODES = ["auto", "fast", "best", "free_first", "compare"]


@dataclass
class ChatMessage:
    role: str  # system | user | assistant
    content: str


@dataclass
class ChatResult:
    text: str
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    quota_info: Optional[Dict[str, Any]] = None  # provider-reported only


@dataclass
class ModelSpec:
    name: str
    capabilities: Set[str] = field(default_factory=lambda: {CAP_TEXT})
    quality: int = 5          # 1-10, user-editable heuristic
    speed: int = 5            # 1-10, user-editable heuristic
    free: bool = False
    strengths: Set[str] = field(default_factory=set)  # task names
    price_in: Optional[float] = None   # USD per 1M tokens, only if user set it
    price_out: Optional[float] = None


class Adapter(Protocol):
    async def chat(self, model: str, messages: List[ChatMessage], *,
                   max_tokens: int, temperature: Optional[float],
                   timeout: float) -> ChatResult: ...


@dataclass
class ProviderRuntime:
    id: str
    kind: str
    adapter: Any
    models: List[ModelSpec]
    priority: int = 100       # lower = preferred
    enabled: bool = True
    is_local: bool = False


@dataclass
class Candidate:
    provider: ProviderRuntime
    model: ModelSpec
    score: float = 0.0

    @property
    def label(self) -> str:
        return f"{self.provider.id}/{self.model.name}"


@dataclass
class RoutingSettings:
    default_mode: str = "auto"
    max_total_attempts: int = 6
    transient_retries: int = 1
    retry_backoff: float = 0.5
    request_timeout: float = 60.0
    compare_count: int = 3
    strict_fallback_order: bool = False
    fallback_order: List[str] = field(default_factory=list)  # provider ids


@dataclass
class Plan:
    task: str
    mode: str
    candidates: List[Candidate]
    skipped: List[Dict[str, str]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


@dataclass
class Outcome:
    content: str
    provider_id: str
    model: str
    task: str
    mode: str
    attempts: List[Dict[str, Any]]
    fallback_used: bool
    warnings: List[str]
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    result: Any = None  # raw adapter result (media routes)
