"""Heuristic, dependency-free task classifier (English + Arabic).

It is intentionally transparent: it returns the signals that matched so the UI
can explain a routing decision. Callers may always override the result.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

TASKS = [
    "general_chat", "programming", "web_research", "writing", "translation",
    "image_generation", "video_generation", "audio_generation",
    "document_analysis", "math",
]

# (pattern, weight)
_RULES: Dict[str, List[tuple]] = {
    "image_generation": [
        (r"\b(generate|create|make|draw|paint|render)\b.{0,30}\b(image|picture|photo|illustration|logo|poster|artwork)\b", 6),
        (r"\b(text[- ]to[- ]image|dall-?e|stable diffusion|midjourney)\b", 6),
        (r"(ارسم|ولّ?د|أنشئ|صمم|اصنع).{0,25}(صورة|صوره|شعار|لوحة|رسمة)", 6),
    ],
    "video_generation": [
        (r"\b(generate|create|make|produce)\b.{0,30}\bvideo\b", 6),
        (r"(أنشئ|اصنع|ولّ?د|انتج).{0,25}(فيديو|مقطع)", 6),
    ],
    "audio_generation": [
        (r"\b(text[- ]to[- ]speech|tts|voice[- ]?over|read (this|it) (aloud|out loud)|generate (audio|music|a song))\b", 6),
        (r"(حوّ?ل.{0,20}(صوت|كلام)|قراءة صوتية|ولّ?د.{0,15}(صوت|موسيقى)|بصوت)", 5),
    ],
    "translation": [
        (r"\btranslate\b|\btranslation\b|\bin (french|spanish|german|arabic|english|chinese|japanese)\b.{0,10}$", 5),
        (r"(ترجم|ترجمة|الى الانجليزية|إلى العربية|الى العربية|إلى الإنجليزية)", 5),
    ],
    "programming": [
        (r"```", 4),
        (r"\b(python|javascript|typescript|java|c\+\+|golang|rust|sql|html|css|bash|react|fastapi|docker|regex|api|bug|stack ?trace|exception|compile|function|class|refactor|unit test)\b", 3),
        (r"\b(write|fix|debug|implement|optimi[sz]e)\b.{0,30}\b(code|script|function|program|query)\b", 5),
        (r"(برمج|كود|الكود|سكربت|خطأ برمجي|اكتب (برنامج|دالة)|بايثون|جافاسكربت)", 4),
    ],
    "math": [
        (r"\b(solve|integral|derivative|equation|prove|theorem|probability|matrix|calculate|compute)\b", 4),
        (r"\d+\s*[\+\-\*/\^=]\s*\d+", 3),
        (r"(احسب|حل المعادلة|معادلة|تكامل|مشتقة|برهن|احتمال|مصفوفة)", 4),
    ],
    "web_research": [
        (r"\b(latest|news|current price|search the web|look up|who won|up[- ]to[- ]date)\b", 4),
        (r"\b(today|currently|recent|recently|2025|2026)\b", 2),
        (r"\b(research|find sources|compare .* online)\b", 4),
        (r"(ابحث|بحث عن|آخر الأخبار|اخر الاخبار|مصادر)", 4),
        (r"(اليوم|حاليا|حالياً)", 2),
    ],
    "document_analysis": [
        (r"\b(summari[sz]e|analy[sz]e|extract|review)\b.{0,40}\b(document|pdf|contract|report|paper|article|text below|attached)\b", 6),
        (r"\b(tl;?dr|key points of)\b", 3),
        (r"(لخص|حلل|استخرج|راجع).{0,30}(المستند|الوثيقة|الملف|العقد|التقرير|النص)", 6),
    ],
    "writing": [
        (r"\b(write|draft|compose|rewrite|proofread|improve)\b.{0,30}\b(email|essay|article|blog|story|poem|letter|post|speech|cover letter|caption)\b", 6),
        (r"(اكتب|صغ|أعد صياغة|حرر).{0,25}(مقال|رسالة|قصة|قصيدة|بريد|خطاب|منشور|نص)", 6),
    ],
}


@dataclass
class Classification:
    task: str
    confidence: float
    scores: Dict[str, int] = field(default_factory=dict)
    signals: List[str] = field(default_factory=list)
    overridden: bool = False


_COMPILED = {t: [(re.compile(p, re.I | re.S), w) for p, w in rules]
             for t, rules in _RULES.items()}


def classify(text: str, *, override: Optional[str] = None,
             has_document: bool = False) -> Classification:
    if override:
        if override not in TASKS:
            raise ValueError(f"unknown task category: {override}")
        return Classification(override, 1.0, overridden=True)

    text = (text or "")[:8000]
    scores: Dict[str, int] = {}
    signals: List[str] = []
    for task, rules in _COMPILED.items():
        total = 0
        for rx, weight in rules:
            if rx.search(text):
                total += weight
                signals.append(f"{task}:{rx.pattern[:40]}")
        if total:
            scores[task] = total
    if has_document:
        scores["document_analysis"] = scores.get("document_analysis", 0) + 5

    if not scores:
        return Classification("general_chat", 0.5, signals=[])
    ranked = sorted(scores.items(), key=lambda kv: (-kv[1], TASKS.index(kv[0])))
    best, best_score = ranked[0]
    if best_score < 3:
        return Classification("general_chat", 0.5, scores, signals)
    second = ranked[1][1] if len(ranked) > 1 else 0
    confidence = round(min(0.99, 0.55 + 0.05 * (best_score - second) + 0.02 * best_score), 2)
    return Classification(best, confidence, scores, signals)
