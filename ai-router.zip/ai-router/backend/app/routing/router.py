"""Routing engine: candidate selection, scoring by mode, bounded fallback."""
from __future__ import annotations

import asyncio
import time
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

from ..errors import (AllProvidersFailedError, NoEligibleModelError,
                      ProviderError, ProviderTimeoutError,
                      RequestRejectedError)
from .types import (CAP_TEXT, CAP_WEB, MODES, TASK_CAPABILITY, Candidate,
                    ChatMessage, Outcome, Plan, ProviderRuntime,
                    RoutingSettings)


class HealthTracker:
    """In-memory availability: cooldowns and parked (auth-failed) providers."""

    def __init__(self, clock: Callable[[], float] = time.monotonic) -> None:
        self._clock = clock
        self._provider_until: Dict[str, float] = {}
        self._model_until: Dict[Tuple[str, str], float] = {}
        self._auth_failed: Dict[str, str] = {}
        self.last_success: Dict[str, float] = {}
        self.reported_quota: Dict[str, Dict[str, Any]] = {}  # provider-reported

    def unavailable_reason(self, pid: str, model: str) -> Optional[str]:
        now = self._clock()
        if pid in self._auth_failed:
            return "authentication_failed"
        if self._provider_until.get(pid, 0) > now:
            return "cooling_down"
        if self._model_until.get((pid, model), 0) > now:
            return "model_cooling_down"
        return None

    def record_success(self, pid: str, quota: Optional[Dict[str, Any]] = None) -> None:
        self.last_success[pid] = time.time()
        self._provider_until.pop(pid, None)
        if quota:
            self.reported_quota[pid] = {**quota, "source": "provider_reported",
                                        "observed_at": time.time()}

    def record_failure(self, pid: str, model: str, err: ProviderError) -> None:
        if err.permanent:
            self._auth_failed[pid] = err.kind
        elif err.kind == "model_not_found":
            self._model_until[(pid, model)] = self._clock() + err.cooldown
        elif err.cooldown:
            self._provider_until[pid] = self._clock() + err.cooldown

    def reset(self, pid: Optional[str] = None) -> None:
        """Call when a provider's configuration changes."""
        if pid is None:
            self._provider_until.clear(); self._model_until.clear(); self._auth_failed.clear()
            return
        self._provider_until.pop(pid, None)
        self._auth_failed.pop(pid, None)
        for key in [k for k in self._model_until if k[0] == pid]:
            self._model_until.pop(key)

    def status(self, pid: str) -> str:
        if pid in self._auth_failed:
            return "auth_failed"
        if self._provider_until.get(pid, 0) > self._clock():
            return "cooling_down"
        return "available"


UsageSink = Callable[[Dict[str, Any]], None]


class Router:
    def __init__(self, get_providers: Callable[[], List[ProviderRuntime]], *,
                 health: Optional[HealthTracker] = None,
                 settings: Optional[RoutingSettings] = None,
                 usage_sink: Optional[UsageSink] = None,
                 sleep: Callable[[float], Awaitable[None]] = asyncio.sleep) -> None:
        self.get_providers = get_providers
        self.health = health or HealthTracker()
        self.settings = settings or RoutingSettings()
        self.usage_sink = usage_sink
        self._sleep = sleep

    # ---------------------------------------------------------------- planning
    def plan(self, task: str, mode: str = "auto") -> Plan:
        if mode not in MODES:
            raise ValueError(f"unknown mode: {mode}")
        needed = TASK_CAPABILITY.get(task)
        if needed is None:
            raise ValueError(f"unknown task: {task}")
        warnings: List[str] = []
        cands, skipped = self._collect(needed, task)
        if not cands and needed == CAP_WEB:
            cands, more = self._collect(CAP_TEXT, task)
            skipped += more
            if cands:
                warnings.append("no_web_search_model: answering without live web access")
        ordered = self._order(cands, task, mode)
        return Plan(task, mode, ordered, skipped, warnings)

    def _collect(self, cap: str, task: str) -> Tuple[List[Candidate], List[Dict[str, str]]]:
        cands: List[Candidate] = []
        skipped: List[Dict[str, str]] = []
        for p in self.get_providers():
            for m in p.models:
                if cap not in m.capabilities:
                    continue
                label = f"{p.id}/{m.name}"
                if not p.enabled:
                    skipped.append({"model": label, "reason": "provider_disabled"})
                    continue
                reason = self.health.unavailable_reason(p.id, m.name)
                if reason:
                    skipped.append({"model": label, "reason": reason})
                    continue
                cands.append(Candidate(p, m))
        return cands, skipped

    def _score(self, c: Candidate, task: str, mode: str) -> float:
        q, s = c.model.quality, c.model.speed
        bonus = 4.0 if task in c.model.strengths else 0.0
        if mode == "fast":
            return s * 4 + q
        if mode == "best":
            return q * 4 + s * 0.5 + bonus
        if mode == "free_first":
            tier = 100.0 if (c.provider.is_local or c.model.free) else 0.0
            return tier + q * 3 + s + bonus
        return q * 3 + s + bonus  # auto / compare

    def _order(self, cands: List[Candidate], task: str, mode: str) -> List[Candidate]:
        for c in cands:
            c.score = self._score(c, task, mode)
        order = self.settings.fallback_order
        if self.settings.strict_fallback_order and order:
            pos = {pid: i for i, pid in enumerate(order)}
            key = lambda c: (pos.get(c.provider.id, len(pos)), -c.score, c.model.name)
        else:
            key = lambda c: (-c.score, c.provider.priority, c.provider.id, c.model.name)
        return sorted(cands, key=key)

    # --------------------------------------------------------------- execution
    async def execute(self, plan: Plan,
                      call: Callable[[Candidate], Awaitable[Any]],
                      *, timeout: Optional[float] = None) -> Tuple[Candidate, Any, List[Dict[str, Any]]]:
        if not plan.candidates:
            raise NoEligibleModelError(
                f"no available model for task '{plan.task}'", plan.skipped)
        s = self.settings
        timeout = timeout or s.request_timeout
        attempts: List[Dict[str, Any]] = []
        for cand in plan.candidates:
            retries = 0
            while len(attempts) < s.max_total_attempts:
                t0 = time.monotonic()
                try:
                    result = await asyncio.wait_for(call(cand), timeout=timeout)
                except asyncio.TimeoutError:
                    err: Optional[ProviderError] = ProviderTimeoutError("timed out")
                except ProviderError as e:
                    err = e
                else:
                    ms = int((time.monotonic() - t0) * 1000)
                    quota = getattr(result, "quota_info", None)
                    self.health.record_success(cand.provider.id, quota)
                    attempts.append(self._attempt(cand, "success", None, ms))
                    self._emit(cand, plan, True, None, ms, result)
                    return cand, result, attempts
                ms = int((time.monotonic() - t0) * 1000)
                attempts.append(self._attempt(cand, "failed", err.kind, ms, err.status))
                self._emit(cand, plan, False, err.kind, ms, None)
                if not err.failover:
                    raise RequestRejectedError(err, attempts)
                if err.retry_same and retries < s.transient_retries:
                    retries += 1
                    await self._sleep(s.retry_backoff * retries)
                    continue
                self.health.record_failure(cand.provider.id, cand.model.name, err)
                break
            if len(attempts) >= s.max_total_attempts:
                break
        raise AllProvidersFailedError(attempts)

    @staticmethod
    def _attempt(cand: Candidate, status: str, error: Optional[str],
                 ms: int, http: Optional[int] = None) -> Dict[str, Any]:
        return {"provider": cand.provider.id, "model": cand.model.name,
                "status": status, "error_type": error, "http_status": http,
                "latency_ms": ms}

    def _emit(self, cand: Candidate, plan: Plan, ok: bool, err: Optional[str],
              ms: int, result: Any) -> None:
        if not self.usage_sink:
            return
        self.usage_sink({
            "provider_id": cand.provider.id, "model": cand.model.name,
            "task": plan.task, "mode": plan.mode, "success": ok,
            "error_type": err, "latency_ms": ms,
            "prompt_tokens": getattr(result, "prompt_tokens", None),
            "completion_tokens": getattr(result, "completion_tokens", None),
            "price_in": cand.model.price_in, "price_out": cand.model.price_out,
        })

    # ------------------------------------------------------------------- chat
    async def chat(self, messages: List[ChatMessage], task: str, mode: str = "auto",
                   *, max_tokens: int = 1024, temperature: Optional[float] = None) -> Outcome:
        """Full conversation history is re-sent to every candidate, so context
        is preserved across fallbacks."""
        plan = self.plan(task, "auto" if mode == "compare" else mode)

        async def call(c: Candidate):
            return await c.provider.adapter.chat(
                c.model.name, messages, max_tokens=max_tokens,
                temperature=temperature, timeout=self.settings.request_timeout)

        cand, res, attempts = await self.execute(plan, call)
        return Outcome(res.text, cand.provider.id, cand.model.name, task, mode,
                       attempts, len(attempts) > 1, plan.warnings,
                       res.prompt_tokens, res.completion_tokens, res)

    async def compare(self, messages: List[ChatMessage], task: str,
                      *, max_tokens: int = 1024, temperature: Optional[float] = None,
                      count: Optional[int] = None) -> List[Dict[str, Any]]:
        plan = self.plan(task, "auto")
        if not plan.candidates:
            raise NoEligibleModelError(f"no available model for task '{task}'", plan.skipped)
        n = count or self.settings.compare_count
        chosen: List[Candidate] = []
        seen = set()
        for c in plan.candidates:             # prefer distinct providers first
            if c.provider.id not in seen:
                chosen.append(c); seen.add(c.provider.id)
        for c in plan.candidates:
            if len(chosen) >= n:
                break
            if c not in chosen:
                chosen.append(c)
        chosen = chosen[:n]

        async def one(c: Candidate) -> Dict[str, Any]:
            t0 = time.monotonic()
            try:
                r = await asyncio.wait_for(c.provider.adapter.chat(
                    c.model.name, messages, max_tokens=max_tokens,
                    temperature=temperature, timeout=self.settings.request_timeout),
                    timeout=self.settings.request_timeout)
            except asyncio.TimeoutError:
                e: Optional[ProviderError] = ProviderTimeoutError("timed out")
            except ProviderError as ex:
                e = ex
            else:
                ms = int((time.monotonic() - t0) * 1000)
                self.health.record_success(c.provider.id, r.quota_info)
                self._emit(c, plan, True, None, ms, r)
                return {"provider": c.provider.id, "model": c.model.name, "ok": True,
                        "content": r.text, "latency_ms": ms}
            ms = int((time.monotonic() - t0) * 1000)
            self.health.record_failure(c.provider.id, c.model.name, e)
            self._emit(c, plan, False, e.kind, ms, None)
            return {"provider": c.provider.id, "model": c.model.name, "ok": False,
                    "error_type": e.kind, "latency_ms": ms}

        return list(await asyncio.gather(*(one(c) for c in chosen)))
