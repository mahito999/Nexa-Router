"""Security helpers: secret redaction, encrypted secret storage, URL
validation, rate limiting and token auth. No third-party deps except
`cryptography`."""
from __future__ import annotations

import hmac
import ipaddress
import logging
import os
import re
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Deque, Dict, Iterable, Optional
from urllib.parse import urlparse

from cryptography.fernet import Fernet, InvalidToken

_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"sk-ant-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"AIza[0-9A-Za-z_\-]{10,}"),
    re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]{8,}"),
    re.compile(r"(?i)(api[_-]?key|x-api-key|x-goog-api-key|authorization|token|secret)"
               r"(\"?\s*[:=]\s*\"?)[^\s\",}&]{4,}"),
]
_extra_secrets: set = set()


def register_secret(value: Optional[str]) -> None:
    """Make an exact secret value redacted everywhere it might be logged."""
    if value and len(value) >= 6:
        _extra_secrets.add(value)


def redact(text: object) -> str:
    out = str(text)
    for s in _extra_secrets:
        out = out.replace(s, "[REDACTED]")
    for rx in _PATTERNS[:4]:
        out = rx.sub("[REDACTED]", out)
    out = _PATTERNS[4].sub(lambda m: f"{m.group(1)}{m.group(2)}[REDACTED]", out)
    return out


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = redact(record.getMessage())
        record.args = ()
        return True


def install_log_redaction() -> None:
    f = RedactingFilter()
    root = logging.getLogger()
    root.addFilter(f)
    for h in root.handlers:
        h.addFilter(f)


class SecretBox:
    """Fernet encryption for API keys stored in the database."""

    def __init__(self, key: str) -> None:
        self._f = Fernet(key.encode() if isinstance(key, str) else key)

    @staticmethod
    def load_or_create(env_key: Optional[str], key_file: str) -> "SecretBox":
        if env_key:
            return SecretBox(env_key)
        if os.path.exists(key_file):
            with open(key_file, "rb") as fh:
                return SecretBox(fh.read().strip())
        os.makedirs(os.path.dirname(key_file) or ".", exist_ok=True)
        key = Fernet.generate_key()
        fd = os.open(key_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as fh:
            fh.write(key)
        return SecretBox(key)

    def encrypt(self, plaintext: str) -> str:
        return self._f.encrypt(plaintext.encode()).decode()

    def decrypt(self, token: str) -> Optional[str]:
        try:
            return self._f.decrypt(token.encode()).decode()
        except InvalidToken:
            return None


_BLOCKED_HOSTS = {"metadata.google.internal", "metadata"}


def validate_base_url(url: str) -> str:
    """Accept only http(s) URLs; block cloud-metadata / link-local targets.
    Private and loopback addresses stay allowed because Ollama and other
    self-hosted models legitimately live there."""
    p = urlparse((url or "").strip())
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("base_url must be an http(s) URL")
    if p.username or p.password:
        raise ValueError("credentials must not be embedded in base_url")
    host = p.hostname.lower()
    if host in _BLOCKED_HOSTS:
        raise ValueError("this host is not allowed")
    try:
        ip = ipaddress.ip_address(host)
        if ip.is_link_local or ip.is_multicast or ip.is_unspecified:
            raise ValueError("this address is not allowed")
    except ValueError as e:
        if "not allowed" in str(e):
            raise
    return url.strip().rstrip("/")


class RateLimiter:
    """Sliding-window limiter, in-memory (use Redis for multi-instance)."""

    def __init__(self, limit: int, window: float = 60.0,
                 clock=time.monotonic) -> None:
        self.limit, self.window, self._clock = limit, window, clock
        self._hits: Dict[str, Deque[float]] = defaultdict(deque)

    def allow(self, key: str) -> bool:
        if self.limit <= 0:
            return True
        now = self._clock()
        q = self._hits[key]
        while q and q[0] <= now - self.window:
            q.popleft()
        if len(q) >= self.limit:
            return False
        q.append(now)
        return True


@dataclass(frozen=True)
class User:
    id: str
    role: str = "user"   # user | admin

    @property
    def is_admin(self) -> bool:
        return self.role == "admin"


def parse_tokens(spec: str) -> Dict[str, User]:
    """'token:userid[:role],token2:userid2' -> {token: User}. Empty = auth off."""
    out: Dict[str, User] = {}
    for part in filter(None, (s.strip() for s in (spec or "").split(","))):
        bits = part.split(":")
        if len(bits) < 2 or not bits[0] or not bits[1]:
            raise ValueError("API tokens must look like token:user[:role]")
        role = bits[2] if len(bits) > 2 else "user"
        if role not in ("user", "admin"):
            raise ValueError("role must be 'user' or 'admin'")
        out[bits[0]] = User(bits[1], role)
    return out


def authenticate(tokens: Dict[str, User], header: Optional[str]) -> Optional[User]:
    if not header or not header.lower().startswith("bearer "):
        return None
    supplied = header[7:].strip()
    found: Optional[User] = None
    for tok, user in tokens.items():          # constant-time per comparison
        if hmac.compare_digest(tok, supplied):
            found = user
    return found
