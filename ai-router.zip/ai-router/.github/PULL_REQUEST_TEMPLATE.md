## Description

<!-- What does this PR do? Link to the related issue if applicable. -->
<!-- Use "Closes #N" to auto-close the issue when this PR is merged. -->

Closes #

---

## Type of change

- [ ] `feat`: New feature
- [ ] `fix`: Bug fix
- [ ] `docs`: Documentation only
- [ ] `refactor`: Code restructure (no behavior change)
- [ ] `perf`: Performance improvement
- [ ] `test`: Tests only
- [ ] `build`: Build system / dependencies
- [ ] `ci`: CI configuration
- [ ] `chore`: Maintenance

---

## Checklist

- [ ] I have read [CONTRIBUTING.md](../docs/CONTRIBUTING.md)
- [ ] My branch is based on `dev`, not `main`
- [ ] My commits follow the [Conventional Commits](https://www.conventionalcommits.org/) format
- [ ] I added or updated tests where appropriate (`cd backend && pytest`)
- [ ] The frontend still builds (`cd frontend && npm run build`)
- [ ] I updated relevant documentation (README, `docs/`, `.env.example`)
- [ ] No secrets, API keys or personal data are included in code, tests, logs or screenshots

---

## How was this tested?

<!-- Commands you ran, providers you tried (mocked or real), screenshots for UI changes. -->
