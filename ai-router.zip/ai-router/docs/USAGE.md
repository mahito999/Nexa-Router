# Usage

## First run

1. Start the app (see [BUILDING.md](BUILDING.md) or the README quick start) and open `http://localhost:8000`.
2. Go to **Providers → Add**.
   - Choose a kind (OpenAI, Anthropic, Gemini, OpenRouter, Ollama, or *OpenAI-compatible* for any custom URL).
   - Enter an API key, or the **name** of an environment variable that holds it (for example `OPENAI_API_KEY`). Keys typed here are stored encrypted on the server and are never shown again.
3. Press **Test connection**, then **Discover models** to import the model list.
4. In the model table adjust quality, speed and the *free* flag. Models found by discovery get name-based starting values, which you should review.

Providers that need a key and have none show **Key missing** and are never used.

## Chatting and modes

| Mode | Use it when |
|---|---|
| Auto | default; best balance for the detected task |
| Fast | you want the quickest answer |
| Best quality | you want the strongest configured model |
| Free-first | prefer local models and ones you flagged free |
| Compare | see several models answer the same question side by side |

The task is detected automatically; pick one in the task menu to override it. Each reply shows **which model actually answered**. When a fallback happened you also see the failed attempts and their error types.

## Routing settings

Under **Routing** you can set the default mode, the attempt cap, retries for transient errors, request timeout, number of models in compare mode, and a fallback order (with *strictly follow* to ignore scores).

## Media

Image generation, text-to-speech and speech-to-text work through OpenAI-compatible providers. Their buttons appear only when a configured model declares the capability (`image_gen`, `tts`, `stt`). Video generation has an interface but no built-in adapter yet.

## Usage dashboard

Per provider: requests, successes, failures, error types, tokens and cost estimates (cost only when you set model prices through the API), last success and availability. Quota is labelled **provider-reported** or **unknown**; the numbers are local counts, not your provider's real quota.

## Local models

- **Ollama**: add the *Ollama* kind (`http://localhost:11434`, or `http://ollama:11434` under Docker Compose with `--profile local`) and run *Discover models*.
- **LM Studio, vLLM, llama.cpp server…**: use *OpenAI-compatible* with the server's `/v1` URL.

## Authentication

For single-user local use leave `AI_ROUTER_API_TOKENS` empty. For shared use set `token:user:role` pairs, serve it over HTTPS and enter your token under **Settings**. Only `admin` users can change providers, routing and system settings.

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| "No eligible model" | no enabled provider with a key supports this task; see the skipped list in the error |
| Provider shows **Auth failed** | key rejected; fix it in Providers (saving clears the state) |
| Provider shows **Cooling down** | recent 429 / outage; it returns automatically |
| Image/audio buttons missing | no configured model declares that capability |
| `409 no_provider_configured` | same as above for the media endpoints |
| Cannot reach the server | backend not running or wrong port; the dev frontend proxies `/api` to `:8000` |
