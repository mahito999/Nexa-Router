# Adding providers

## Any OpenAI-compatible server (no code)

Providers → Add → kind **OpenAI-compatible (custom URL)**, set the base URL (e.g. `http://localhost:1234/v1` for LM Studio, `http://vllm:8000/v1`), optionally a key, then *Discover models*.

## A new API (plugin)

Write an adapter and register it. Set `AI_ROUTER_PLUGINS=my_plugin` (a module on `PYTHONPATH`).

```python
# my_plugin.py
from typing import List, Optional
from app.providers.base import HttpAdapter
from app.providers.registry import KindTemplate, register_kind
from app.routing.types import ChatMessage, ChatResult


class MyAdapter(HttpAdapter):
    kind = "myprovider"

    def _headers(self):
        return {"content-type": "application/json", "authorization": f"Bearer {self._api_key}"}

    async def chat(self, model, messages: List[ChatMessage], *, max_tokens, temperature, timeout):
        r = await self._request("POST", "/v1/generate", timeout=timeout,
                                json={"model": model, "max_tokens": max_tokens,
                                      "messages": [m.__dict__ for m in messages]})
        return ChatResult(r.json()["text"])

    async def list_models(self, timeout: float = 15.0) -> List[str]:
        r = await self._request("GET", "/v1/models", timeout=timeout)
        return [m["id"] for m in r.json()["models"]]


register_kind(KindTemplate("myprovider", "My Provider", "https://api.example.com",
                           "MYPROVIDER_API_KEY", True, False,
                           lambda base, key, client: MyAdapter(base, key, client)))
```

`self._request` already converts timeouts, connection failures and HTTP status codes (429, quota text, 401/403, 5xx) into the typed errors the router understands, so fallback works for your adapter without extra code.

To offer image/TTS/STT, implement `generate_image` / `text_to_speech` / `speech_to_text` and list them in `supported_media = {"image_gen", "tts", "stt"}`. Without that declaration the UI will not offer the capability.
