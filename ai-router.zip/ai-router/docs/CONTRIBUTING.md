# Contributing to AI Router

Thank you for considering a contribution. Every contribution, big or small, matters.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Ways to contribute](#ways-to-contribute)
- [Development setup](#development-setup)
- [Project structure](#project-structure)
- [Coding standards](#coding-standards)
- [Branching strategy](#branching-strategy)
- [Commit messages](#commit-messages)
- [Opening a pull request](#opening-a-pull-request)
- [Adding a provider](#adding-a-provider)
- [Security vulnerabilities](#security-vulnerabilities)

## Code of Conduct

Be respectful. See [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md).

## Ways to contribute

- **Report bugs** with a [GitHub issue](https://github.com/OWNER/ai-router/issues), with secrets removed.
- **Test real providers**: the automated tests mock HTTP, so reports from real OpenAI / Anthropic / Gemini / Ollama setups are very valuable.
- **Improve the classifier** for more languages and edge cases.
- **Translate** the interface (`frontend/src/i18n.ts`).
- **Write adapters** for new APIs, or video / audio generation providers.
- **Improve documentation.**

## Development setup

See [BUILDING.md](BUILDING.md). In short:

```bash
cd backend && pip install -r requirements-dev.txt && pytest
cd frontend && npm install && npm run build
```

## Project structure

See the table in [ARCHITECTURE.md](ARCHITECTURE.md#overview).

## Coding standards

**Python**
- Type hints on public functions; keep adapters small and stateless.
- Convert every transport or HTTP failure into a typed `ProviderError`; never let raw upstream bodies reach responses or logs.
- Never log, return or commit secrets. New secret-bearing fields must go through `security.register_secret` / `SecretBox`.
- New behaviour needs a test; provider tests mock HTTP.

**TypeScript / React**
- `strict` TypeScript, no `any` in new code where a type is practical.
- Every user-facing string goes in `i18n.ts` for **both** `ar` and `en`.
- Use logical CSS (`ms-`, `pe-`, `text-start`) so RTL and LTR both work; check both.
- Do not add UI for a capability that no configured provider supports.

## Branching strategy

| Branch | Purpose |
|---|---|
| `main` | stable, tagged releases |
| `dev` | integration branch; open PRs against this |
| `feature/<name>`, `fix/<name>`, `docs/<name>` | topic branches |

## Commit messages

[Conventional Commits](https://www.conventionalcommits.org/): `type(scope): summary`.

Types: `feat`, `fix`, `docs`, `refactor`, `perf`, `test`, `build`, `ci`, `chore`. Examples:

```
feat(router): add strict fallback order
fix(openai): send max_completion_tokens for official API
docs: add Termux instructions
```

## Opening a pull request

1. Fork, branch from `dev`.
2. Run `pytest` and `npm run build`.
3. Fill in the PR template and link the issue.
4. CI runs backend tests (Python 3.11–3.13), the frontend build, a Docker build and CodeQL.

## Adding a provider

OpenAI-compatible servers need no code. For anything else, follow [PROVIDERS.md](PROVIDERS.md) and add adapter tests using `httpx.MockTransport` (see `backend/tests/test_adapters.py`).

## Security vulnerabilities

Do not open public issues for vulnerabilities. See [SECURITY.md](SECURITY.md).
