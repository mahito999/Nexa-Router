# Building and running from source

Requirements: Python 3.11+, Node.js 20+ (22 recommended), optionally Docker.

## Docker

```bash
cp .env.example .env
docker compose up --build          # http://localhost:8000
docker compose --profile local up --build   # plus an Ollama container
```

Data (SQLite DB and the generated secret key) lives in the `ai_router_data` volume.

## Linux / macOS

```bash
# backend
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:get_app --factory --reload --port 8000

# frontend (second terminal)
cd frontend
npm install
npm run dev                        # http://localhost:5173, proxies /api to :8000
```

To serve the production build from the backend: `npm run build`, then start uvicorn with `FRONTEND_DIST=../frontend/dist`.

## Windows (PowerShell)

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
uvicorn app.main:get_app --factory --reload --port 8000
# new terminal
cd frontend; npm install; npm run dev
```

## Android (Termux)

Install Termux from **F-Droid**, copy the project to the phone, then:

```bash
bash termux-install.sh   # one time; compiling some packages can take 10–20 minutes
bash termux-run.sh       # open http://localhost:8000
```

Large local models are impractical on a phone; point an Ollama provider at another machine instead.

## Android APK

The APK bundles the web interface only. **The API does not run inside the app**, so it connects to an AI Router server you run (a PC, a VPS, Docker, or Termux on the same phone at `http://localhost:8000`).

**From GitHub Actions** (no local setup): the *Android APK* workflow builds `ai-router-<ref>-debug.apk`. Download it from the run's *Artifacts*, or from the release when you push a `v*` tag.

**Locally** (needs JDK 17 and the Android SDK):

```bash
cd frontend
npm install && npm run build
npx cap add android && npx cap sync android
cd android && ./gradlew assembleDebug
# APK: frontend/android/app/build/outputs/apk/debug/app-debug.apk
```

**Using it**

1. On the server set `CORS_ORIGINS=http://localhost` (and your `AI_ROUTER_API_TOKENS` if you use auth), then restart it.
2. Install the APK (allow *install unknown apps*).
3. On first launch enter the **Server URL**, for example `http://192.168.1.10:8000`, then add your access token under Settings if auth is enabled.

The workflow produces a *debug*-signed APK, which is fine for personal use. For Play Store distribution you must create a release keystore and sign the build yourself.

## Configuration

All settings are environment variables; see [`.env.example`](../.env.example). The app does not read `.env` itself outside Docker Compose; export the variables or `set -a; source .env; set +a`.

## Tests

```bash
cd backend && pytest -q
cd frontend && npm run typecheck && npm run build
```

- `test_classifier.py`, `test_router.py`, `test_errors_security.py`: classification, provider selection, fallback, quota / auth / timeout handling, retry caps, secret handling, URL validation, rate limiting, token auth.
- `test_adapters.py`, `test_api.py`: HTTP is mocked with `httpx.MockTransport`; no real keys needed. They are skipped when `httpx`, `fastapi` or `sqlalchemy` are missing.

## Switching to PostgreSQL

Install a driver (`pip install "psycopg[binary]"`) and set `DATABASE_URL=postgresql+psycopg://user:pass@host:5432/ai_router`.
