# Code of Conduct

## Our Pledge

We want participation in AI Router to be a harassment-free experience for everyone, regardless of age, disability, ethnicity, gender identity, level of experience, nationality, appearance, race, religion, or sexual identity and orientation.

## Our Standards

Behaviour that contributes to a positive environment:

- Being welcoming and patient with newcomers
- Giving and accepting constructive feedback gracefully
- Focusing on what is best for the project and community
- Writing in English or Arabic; we are glad to help translate

Unacceptable behaviour:

- Harassment, insults, or personal or political attacks
- Publishing other people's private information, including API keys or personal data found in logs
- Spam or promotional content unrelated to the project
- Other conduct that would reasonably be considered inappropriate in a professional setting

## Enforcement

Maintainers may edit or remove comments, commits, issues and other contributions that do not follow this Code of Conduct, and may temporarily or permanently restrict participation.

Report problems by contacting the maintainers through a private GitHub security advisory or the contact listed on the maintainer's profile. All reports are handled promptly and confidentially.

## Attribution

Adapted in spirit from the [Contributor Covenant](https://www.contributor-covenant.org/), version 2.1.
