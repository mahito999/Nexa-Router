# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| `main` branch | Active development |
| Tagged releases | Critical fixes backported |
| Older releases | No longer supported |

AI Router is pre-1.0. Once 1.0 is released this policy will cover the current stable release and the previous minor version.

## Reporting a Vulnerability

**Do not open a public GitHub issue for security vulnerabilities.**

Report privately through GitHub's security advisory feature:

**[Report a vulnerability](https://github.com/OWNER/ai-router/security/advisories/new)**

Please include:

- A description of the issue and its impact
- Steps to reproduce (version, how you run it, provider involved)
- Proof-of-concept code or logs, **with any API keys removed**
- A suggested fix if you have one

## Response Timeline

| Step | Target time |
|------|-------------|
| Acknowledgement | 72 hours |
| Initial assessment | 7 days |
| Fix for critical issues | 14 days |
| Fix for moderate issues | 60 days |
| Public disclosure | After a fix is released |

These are good-faith targets for a volunteer project, not guarantees.

## Scope

In scope:

- Exposure of provider API keys or access tokens (API responses, logs, errors, the database)
- Authentication / authorization bypass (roles, per-user conversation privacy)
- Server-side request forgery through provider base URLs
- Injection, path traversal, or unsafe handling of uploaded audio / documents
- Denial of service that bypasses the configured rate limits

Out of scope:

- Issues in third-party providers' own services
- Findings that require an already-compromised host or a stolen admin token
- Running the app on an open network with authentication disabled (`AI_ROUTER_API_TOKENS` empty) — this is documented as single-user local mode
- Missing HTTPS: terminate TLS in a reverse proxy

## Hardening checklist for deployments

- Set `AI_ROUTER_API_TOKENS` with long random tokens and serve behind HTTPS.
- Set `APP_SECRET_KEY` and back it up; without it stored keys cannot be decrypted.
- Prefer environment variables (or a secrets manager) for provider keys.
- Keep `data/` out of version control and restrict its permissions.
