# AI Router Documentation

A guide to every document in this folder.

## For users

- **[USAGE.md](USAGE.md)**: adding providers, routing modes, compare mode, media, usage dashboard, troubleshooting.
- **[PROVIDERS.md](PROVIDERS.md)**: connecting OpenAI-compatible servers and writing a provider plugin.
- **[PRIVACY.md](PRIVACY.md)**: what is stored, what leaves your server, what is never collected.

## For developers

- **[ARCHITECTURE.md](ARCHITECTURE.md)**: components, request flow, the fallback rules, error taxonomy, data model and security model.
- **[BUILDING.md](BUILDING.md)**: running from source on Linux, Windows, Android (Termux) and Docker; running the tests.
- **[CONTRIBUTING.md](CONTRIBUTING.md)**: branching, commit messages, coding standards, pull requests.

## Project policies

- **[SECURITY.md](SECURITY.md)**: how to report a vulnerability privately.
- **[CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md)**: how we treat each other.
- **[../CHANGELOG.md](../CHANGELOG.md)**: release history.
