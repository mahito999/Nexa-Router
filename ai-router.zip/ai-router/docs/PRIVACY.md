# Privacy

AI Router is self-hosted software. The project does not operate a server, receive your data, or include analytics or telemetry. Everything below happens on infrastructure **you** run.

## What is stored on your server

| Data | Where | Notes |
|---|---|---|
| Provider API keys | database, encrypted (Fernet) | or read from environment variables; never returned by the API |
| Conversations and messages | database | private per user when authentication is enabled |
| Usage records | database | provider, model, task, status, latency, token counts |
| Settings | database | routing and system settings |
| Encryption key | `data/.secret_key` (mode 600) | or `APP_SECRET_KEY` |
| Browser | `localStorage` | interface language and, if you set one, your access token |

## What leaves your server

Only the requests you make: your messages (and full conversation context on fallback) are sent to the provider(s) you configured, under **their** terms and privacy policies. A fallback sends the same context to the next provider in the chain, so enable only providers you are comfortable sharing prompts with.

The web interface loads no third-party fonts, scripts or trackers.

## Logs

Logs redact registered secrets and common API-key formats. Upstream error bodies are not forwarded to clients. Message contents are not written to logs.

## Your control

Delete a conversation from **History**, a provider from **Providers**, or remove the `data/` directory to erase everything.
