# Architecture

## Overview

```
 Browser (React + TS + Tailwind, Arabic RTL / English)
        │  /api/*   (bearer token optional)
        ▼
 FastAPI app ── security (auth, rate limit, redaction, URL guard)
        │
        ├── Classifier ──► task category
        ├── Router ──► plan (eligible, ranked models) ──► execute with fallback
        │                    │
        │              HealthTracker (cooldowns, parked providers)
        ▼
 Provider adapters (httpx, async) ──► OpenAI · Anthropic · Gemini · OpenRouter · Ollama · any OpenAI-compatible
        │
 SQLite / PostgreSQL (providers, usage, conversations, settings)
```

Source layout:

| Path | Responsibility |
|---|---|
| `backend/app/errors.py` | Error taxonomy and HTTP-status → error classification |
| `backend/app/routing/classifier.py` | Heuristic task classifier (English + Arabic) |
| `backend/app/routing/router.py` | Candidate selection, scoring by mode, bounded fallback, compare |
| `backend/app/routing/types.py` | Dataclasses shared by router, adapters and API |
| `backend/app/providers/` | One adapter per API family + `registry.py` (plugin point) |
| `backend/app/security.py` | Redaction, Fernet secret box, URL validation, rate limiter, token auth |
| `backend/app/service.py`, `db.py` | Persistence, usage tracking, per-user limits |
| `backend/app/main.py` | REST API and static hosting of the built frontend |
| `frontend/src/` | Pages: Chat, Models, Providers, Routing, Usage, History, Settings |

## Request flow

1. The API validates the body (Pydantic) and the message length, applies the rate limiter and per-user daily limits.
2. `classify()` picks a task category, unless the caller overrides it.
3. `Router.plan(task, mode)` collects every model whose configured capabilities cover the task, from providers that are enabled, have a key (or need none) and are not cooling down; then orders them by mode.
4. `Router.execute()` calls candidates in order. The full conversation history is re-sent to each candidate, so context survives a fallback.
5. The response reports which provider and model answered, every attempt with its error type, and any warnings.

## Task categories and capabilities

| Task | Capability required |
|---|---|
| general chat, programming, writing, translation, document analysis, math | `text` |
| web research | `web_search` (falls back to `text` with a warning) |
| image generation | `image_gen` |
| audio generation (text-to-speech) | `tts` |
| video generation | `video_gen` (interface only, no built-in adapter) |

Capabilities come from what you configure per model. Media capabilities are additionally dropped unless the provider's adapter declares support, so the UI never offers a control that cannot work.

## Modes

| Mode | Ordering |
|---|---|
| `auto` | quality ×3 + speed + bonus when the model lists the task in its strengths |
| `fast` | speed first |
| `best` | quality first, strengths weighted higher |
| `free_first` | local providers and models flagged *free* first, then by quality |
| `compare` | top models from distinct providers are called in parallel and shown side by side |

Quality and speed are **editable heuristics (1–10)**, not benchmarks. Optionally enable *strict fallback order* to use the provider order from the Routing page instead of scores.

## Fallback rules

| Situation | Classified as | Behaviour |
|---|---|---|
| HTTP 429 | `rate_limit` | cooldown (honours `Retry-After`), try next model |
| 429 / 402 / billing text | `quota_exhausted` | long cooldown, try next model |
| 5xx, 529, 408 | `transient` | one bounded retry, then next model |
| Timeout / connection error | `timeout` / `connection` | one bounded retry, then next model |
| 401 / 403 / invalid key | `authentication` | **never retried**; provider parked until its config changes |
| 404 model | `model_not_found` | that model is skipped for a while |
| 400 / 422 | `invalid_request` | returned to the caller; **not** sent to other providers |

Total attempts per request are capped (`max_total_attempts`, default 6) so there are no retry loops. Fallback only moves a request to another provider **you configured**. It never pools, transfers or bypasses any provider's quota or authentication.

## Usage tracking

Every attempt is stored. The dashboard separates three things and never invents numbers:

- **Provider-reported**: values taken from rate-limit response headers, when the provider sends them.
- **Locally counted**: requests, successes, failures and token counts returned in responses; cost only when you entered per-model prices.
- **Unknown**: shown as unknown.

## Data model

`providers` (encrypted key, base URL, priority, models JSON), `usage`, `conversations`, `messages`, `kv` (routing and system settings). Schema is created on start; use Alembic before changing models in production.

## Security model

- Provider keys live only on the server: encrypted with Fernet (`APP_SECRET_KEY` or an auto-generated `data/.secret_key`, mode 600) or read from environment variables. The API never returns them.
- Registered secrets and common key formats are redacted from logs. Upstream error bodies are used for classification only and never forwarded.
- Provider base URLs must be `http(s)`, contain no credentials and may not target link-local / metadata addresses (private and loopback stay allowed for Ollama and self-hosted servers).
- Optional bearer-token auth (`token:user:role`) with `admin` and `user` roles; conversations are private per user.
- Sliding-window rate limiter (in-memory) and optional per-user daily request/token limits. Both are configurable; `0` disables them.

## Extension points

- **New provider**: register a `KindTemplate` (see [PROVIDERS.md](PROVIDERS.md)); `AI_ROUTER_PLUGINS=module` loads it at start.
- **New media type**: implement the corresponding adapter method and add it to `supported_media`.
- **Task rules**: extend the pattern table in `routing/classifier.py`.
