import { ReactNode, ButtonHTMLAttributes, InputHTMLAttributes, SelectHTMLAttributes } from "react";

export const Card = ({ children, className = "" }: { children: ReactNode; className?: string }) => (
  <div className={`rounded-2xl border border-ink-700 bg-ink-900 p-4 ${className}`}>{children}</div>
);

export const Spinner = () => <span className="spinner" role="status" aria-label="loading" />;

export const Btn = ({ variant = "primary", className = "", ...p }:
  ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" }) => {
  const v = {
    primary: "bg-accent text-ink-950 hover:brightness-110",
    ghost: "border border-ink-700 text-slate-200 hover:bg-ink-800",
    danger: "border border-red-900 text-red-300 hover:bg-red-950",
  }[variant];
  return <button {...p} className={`rounded-xl px-3 py-2 text-sm font-medium transition disabled:opacity-50 ${v} ${className}`} />;
};

const field = "w-full rounded-xl border border-ink-700 bg-ink-950 px-3 py-2 text-sm outline-none focus:border-accent";
export const Input = (p: InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={`${field} ${p.className ?? ""}`} />;
export const Select = (p: SelectHTMLAttributes<HTMLSelectElement>) => <select {...p} className={`${field} ${p.className ?? ""}`} />;

export const Label = ({ text, children }: { text: string; children: ReactNode }) => (
  <label className="block space-y-1"><span className="text-xs text-slate-400">{text}</span>{children}</label>
);

const tones: Record<string, string> = {
  ok: "bg-emerald-950 text-emerald-300 border-emerald-900",
  warn: "bg-amber-950 text-amber-300 border-amber-900",
  bad: "bg-red-950 text-red-300 border-red-900",
  mute: "bg-ink-800 text-slate-300 border-ink-700",
};
export const Badge = ({ children, tone = "mute" }: { children: ReactNode; tone?: keyof typeof tones }) => (
  <span className={`inline-block rounded-full border px-2 py-0.5 text-xs ${tones[tone]}`}>{children}</span>
);

export const ErrorBox = ({ message }: { message: string }) =>
  message ? <div role="alert" className="rounded-xl border border-red-900 bg-red-950/60 p-3 text-sm text-red-200">{message}</div> : null;

export const statusTone = (s: string) =>
  s === "available" ? "ok" : s === "disabled" ? "mute" : s === "cooling_down" || s === "missing_key" ? "warn" : "bad";
