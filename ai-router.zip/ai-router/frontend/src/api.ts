// Thin API client. The only credential kept in the browser is the user's own
// access token (when server auth is enabled). Provider API keys never reach here.
const TOKEN_KEY = "ai_router_token";

export const getToken = (): string => {
  try { return localStorage.getItem(TOKEN_KEY) ?? ""; } catch { return ""; }
};
export const setToken = (v: string): void => {
  try { v ? localStorage.setItem(TOKEN_KEY, v) : localStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ }
};

const SERVER_KEY = "ai_router_server";

/** Base URL of the AI Router server. Empty = same origin (web / Docker / Termux).
 *  The Android app needs it, because the API does not run inside the APK. */
export const getServerUrl = (): string => {
  try { return localStorage.getItem(SERVER_KEY) ?? ""; } catch { return ""; }
};
export const setServerUrl = (v: string): void => {
  const clean = v.trim().replace(/\/+$/, "");
  try {
    if (/^https?:\/\/[^\s]+$/i.test(clean)) localStorage.setItem(SERVER_KEY, clean);
    else localStorage.removeItem(SERVER_KEY);
  } catch { /* ignore */ }
};

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string, public detail?: unknown) {
    super(message);
  }
}

export async function api<T = any>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  const headers: Record<string, string> = { "content-type": "application/json" };
  const tok = getToken();
  if (tok) headers.authorization = `Bearer ${tok}`;
  let res: Response;
  try {
    res = await fetch(`${getServerUrl()}/api${path}`, {
      method: init.method ?? "GET",
      headers,
      body: init.body === undefined ? undefined : JSON.stringify(init.body),
    });
  } catch {
    throw new ApiError(0, "network", "Cannot reach the server");
  }
  if (res.status === 204) return undefined as T;
  let data: any = null;
  try { data = await res.json(); } catch { /* non-JSON */ }
  if (!res.ok) {
    const d = data?.detail;
    const code = typeof d === "object" && d?.code ? d.code : "error";
    const msg = typeof d === "string" ? d : d?.message ?? (d?.errors?.[0]?.message) ?? `HTTP ${res.status}`;
    throw new ApiError(res.status, code, msg, d);
  }
  return data as T;
}

export interface ModelCfg {
  name: string; capabilities: string[]; quality: number; speed: number; free: boolean;
  strengths: string[]; price_in: number | null; price_out: number | null;
}
export interface Provider {
  id: string; name: string; kind: string; base_url: string; api_key_env: string | null;
  key_source: "env" | "stored" | "none"; enabled: boolean; priority: number; is_local: boolean;
  status: string; models: ModelCfg[];
}
export interface Meta {
  auth_enabled: boolean; user: { id: string; role: string }; modes: string[]; tasks: string[];
  kinds: { kind: string; label: string; default_base_url: string | null; default_key_env: string | null; requires_key: boolean; is_local: boolean }[];
  system: { default_language: "ar" | "en"; max_context_messages: number; user_daily_request_limit: number | null; user_daily_token_limit: number | null };
}
