import { useEffect, useState } from "react";
import { api, ApiError, Meta } from "./api";
import { Key, Lang, t } from "./i18n";
import { ErrorBox, Spinner } from "./components/ui";
import Chat from "./pages/Chat";
import Models from "./pages/Models";
import Providers from "./pages/Providers";
import Routing from "./pages/Routing";
import Usage from "./pages/Usage";
import History from "./pages/History";
import Settings from "./pages/Settings";

export type PageProps = { lang: Lang; meta: Meta; go: (p: string) => void; openConv: number | null; setOpenConv: (id: number | null) => void };

const PAGES: { id: string; label: Key; icon: string }[] = [
  { id: "chat", label: "nav_chat", icon: "💬" },
  { id: "models", label: "nav_models", icon: "🧠" },
  { id: "providers", label: "nav_providers", icon: "🔌" },
  { id: "routing", label: "nav_routing", icon: "🔀" },
  { id: "usage", label: "nav_usage", icon: "📊" },
  { id: "history", label: "nav_history", icon: "🕘" },
  { id: "settings", label: "nav_settings", icon: "⚙️" },
];

export default function App() {
  const [meta, setMeta] = useState<Meta | null>(null);
  const [err, setErr] = useState("");
  const [lang, setLang] = useState<Lang>(() => {
    try { return (localStorage.getItem("lang") as Lang) || "ar"; } catch { return "ar"; }
  });
  const [page, setPage] = useState("chat");
  const [openConv, setOpenConv] = useState<number | null>(null);
  const [menu, setMenu] = useState(false);

  const load = () => api<Meta>("/meta").then(setMeta).catch((e: ApiError) => setErr(e.message));
  useEffect(() => { load(); }, [page === "settings"]);
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    try { localStorage.setItem("lang", lang); } catch { /* ignore */ }
  }, [lang]);

  const props = meta && { lang, meta, go: setPage, openConv, setOpenConv };
  const body = props && (
    page === "chat" ? <Chat {...props} /> :
    page === "models" ? <Models {...props} /> :
    page === "providers" ? <Providers {...props} /> :
    page === "routing" ? <Routing {...props} /> :
    page === "usage" ? <Usage {...props} /> :
    page === "history" ? <History {...props} /> :
    <Settings {...props} setLang={setLang} reload={load} />
  );

  return (
    <div className="flex h-full flex-col md:flex-row">
      <header className="flex items-center justify-between border-b border-ink-700 bg-ink-900 px-4 py-3 md:hidden">
        <strong>{t(lang, "appName")}</strong>
        <button aria-label="menu" onClick={() => setMenu(!menu)} className="text-xl">☰</button>
      </header>
      <nav className={`${menu ? "block" : "hidden"} w-full shrink-0 border-ink-700 bg-ink-900 p-3 md:block md:w-60 md:border-e`}>
        <div className="mb-4 hidden px-2 text-lg font-bold text-accent md:block">{t(lang, "appName")}</div>
        <ul className="space-y-1">
          {PAGES.map((p) => (
            <li key={p.id}>
              <button
                onClick={() => { setPage(p.id); setMenu(false); }}
                className={`flex w-full items-center gap-3 rounded-xl px-3 py-2 text-start text-sm transition ${page === p.id ? "bg-ink-700 text-white" : "text-slate-400 hover:bg-ink-800"}`}>
                <span aria-hidden>{p.icon}</span>{t(lang, p.label)}
              </button>
            </li>
          ))}
        </ul>
      </nav>
      <main className="min-h-0 flex-1 overflow-y-auto p-4 md:p-6">
        <ErrorBox message={err} />
        {!meta && !err ? <Spinner /> : body}
      </main>
    </div>
  );
}
