import { useEffect, useState } from "react";
import { api, ApiError } from "../api";
import { t } from "../i18n";
import { Badge, Card, ErrorBox, Spinner } from "../components/ui";
import type { PageProps } from "../App";

export default function Models({ lang }: PageProps) {
  const [rows, setRows] = useState<any[] | null>(null);
  const [err, setErr] = useState("");
  useEffect(() => { api("/models").then(setRows).catch((e: ApiError) => setErr(e.message)); }, []);
  return (
    <div className="mx-auto max-w-6xl space-y-4">
      <h1 className="text-xl font-bold">{t(lang, "nav_models")}</h1>
      <ErrorBox message={err} />
      {!rows && !err && <Spinner />}
      {rows?.length === 0 && <p className="text-slate-400">{t(lang, "noProviders")}</p>}
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {rows?.map((m) => (
          <Card key={`${m.provider_id}/${m.name}`}>
            <div className="flex items-start justify-between gap-2">
              <div><div className="font-medium break-all">{m.name}</div><div className="text-xs text-slate-400">{m.provider_id} · {m.provider_kind}</div></div>
              <Badge tone={m.available ? "ok" : "warn"}>{m.available ? t(lang, "available") : t(lang, "unavailable")}</Badge>
            </div>
            <div className="mt-3 flex flex-wrap gap-1">
              {m.capabilities.map((c: string) => <Badge key={c}>{c}</Badge>)}
              {m.local && <Badge tone="ok">local</Badge>}
              {m.free && <Badge tone="ok">{t(lang, "free")}</Badge>}
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-slate-400">
              <span>{t(lang, "quality")}: {m.quality}/10</span><span>{t(lang, "speed")}: {m.speed}/10</span>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
