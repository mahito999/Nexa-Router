import { useEffect, useState } from "react";
import { api, ApiError, ModelCfg, Provider } from "../api";
import { Key, t } from "../i18n";
import { Badge, Btn, Card, ErrorBox, Input, Label, Select, Spinner, statusTone } from "../components/ui";
import type { PageProps } from "../App";

const empty = { id: "", name: "", kind: "openai", base_url: "", api_key: "", api_key_env: "", priority: 100 };

export default function Providers({ lang, meta }: PageProps) {
  const [list, setList] = useState<Provider[] | null>(null);
  const [form, setForm] = useState(empty);
  const [err, setErr] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState("");
  const admin = meta.user.role === "admin";

  const load = () => api<Provider[]>("/providers").then(setList).catch((e: ApiError) => setErr(e.message));
  useEffect(() => { load(); }, []);
  const run = async (key: string, fn: () => Promise<any>) => {
    setBusy(key); setErr(""); setNote("");
    try { await fn(); await load(); } catch (e) { setErr((e as ApiError).message); } finally { setBusy(""); }
  };
  const kind = meta.kinds.find((k) => k.kind === form.kind);

  const add = () => run("add", async () => {
    await api("/providers", { method: "POST", body: {
      id: form.id, name: form.name || form.id, kind: form.kind,
      base_url: form.base_url || undefined, api_key: form.api_key || undefined,
      api_key_env: form.api_key_env || undefined, priority: Number(form.priority),
    } });
    setForm(empty); setNote(t(lang, "saved"));
  });
  const test = (p: Provider) => run("t" + p.id, async () => {
    const r = await api(`/providers/${p.id}/test`, { method: "POST" });
    setNote(r.ok ? `${p.id}: OK (${r.models_found})` : `${p.id}: ${r.error_type}${r.http_status ? " " + r.http_status : ""}`);
  });
  const discover = (p: Provider) => run("d" + p.id, async () => {
    const found: ModelCfg[] = await api(`/providers/${p.id}/discover-models`);
    const have = new Set(p.models.map((m) => m.name));
    await api(`/providers/${p.id}`, { method: "PATCH", body: { models: [...p.models, ...found.filter((m) => !have.has(m.name))] } });
  });
  const patch = (p: Provider, body: object) => run("p" + p.id, () => api(`/providers/${p.id}`, { method: "PATCH", body }));
  const editModel = (p: Provider, i: number, change: Partial<ModelCfg>) =>
    patch(p, { models: p.models.map((m, j) => (j === i ? { ...m, ...change } : m)) });

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <h1 className="text-xl font-bold">{t(lang, "nav_providers")}</h1>
      <ErrorBox message={err} />
      {note && <Badge tone="ok">{note}</Badge>}
      {!list && !err && <Spinner />}
      {list?.length === 0 && <p className="text-slate-400">{t(lang, "noProviders")}</p>}

      {list?.map((p) => (
        <Card key={p.id} className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div><span className="font-medium">{p.name}</span> <span className="text-xs text-slate-500">({p.id} · {p.kind})</span>
              <div className="text-xs text-slate-500 break-all">{p.base_url}</div></div>
            <div className="flex items-center gap-2">
              <Badge tone={statusTone(p.status)}>{t(lang, `st_${p.status}` as Key)}</Badge>
              {p.key_source !== "none" && <Badge>{p.key_source === "env" ? "env" : "stored key"}</Badge>}
            </div>
          </div>
          {admin && (
            <div className="flex flex-wrap items-end gap-2">
              <Btn variant="ghost" onClick={() => patch(p, { enabled: !p.enabled })}>{p.enabled ? t(lang, "disabled") : t(lang, "enabled")}</Btn>
              <Btn variant="ghost" onClick={() => test(p)} disabled={busy === "t" + p.id}>{busy === "t" + p.id ? <Spinner /> : t(lang, "test")}</Btn>
              <Btn variant="ghost" onClick={() => discover(p)} disabled={busy === "d" + p.id}>{busy === "d" + p.id ? <Spinner /> : t(lang, "discover")}</Btn>
              <div className="w-24"><Label text={t(lang, "priority")}>
                <Input type="number" defaultValue={p.priority} onBlur={(e) => Number(e.target.value) !== p.priority && patch(p, { priority: Number(e.target.value) })} /></Label></div>
              <Btn variant="danger" onClick={() => confirm(t(lang, "confirmDelete")) && run("x", () => api(`/providers/${p.id}`, { method: "DELETE" }))}>{t(lang, "delete")}</Btn>
            </div>
          )}
          {p.models.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full text-start text-xs">
                <thead className="text-slate-400"><tr>
                  <th className="p-1 text-start">{t(lang, "models")}</th><th className="p-1 text-start">{t(lang, "capabilities")}</th>
                  <th className="p-1">{t(lang, "quality")}</th><th className="p-1">{t(lang, "speed")}</th><th className="p-1">{t(lang, "free")}</th></tr></thead>
                <tbody>{p.models.map((m, i) => (
                  <tr key={m.name} className="border-t border-ink-700">
                    <td className="p-1 break-all">{m.name}</td>
                    <td className="p-1">{m.capabilities.join(", ")}</td>
                    {(["quality", "speed"] as const).map((f) => (
                      <td key={f} className="p-1"><input type="number" min={1} max={10} disabled={!admin} defaultValue={m[f]}
                        onBlur={(e) => { const v = Number(e.target.value); if (v !== m[f]) editModel(p, i, f === "quality" ? { quality: v } : { speed: v }); }}
                        className="w-14 rounded-lg border border-ink-700 bg-ink-950 p-1 text-center" /></td>
                    ))}
                    <td className="p-1 text-center"><input type="checkbox" disabled={!admin} checked={m.free} onChange={(e) => editModel(p, i, { free: e.target.checked })} /></td>
                  </tr>))}</tbody>
              </table>
            </div>
          )}
        </Card>
      ))}

      {admin && (
        <Card className="space-y-3">
          <h2 className="font-medium">{t(lang, "add")}</h2>
          <div className="grid gap-3 md:grid-cols-2">
            <Label text={t(lang, "kind")}><Select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
              {meta.kinds.map((k) => <option key={k.kind} value={k.kind}>{k.label}</option>)}</Select></Label>
            <Label text={t(lang, "providerId")}><Input value={form.id} placeholder="my-openai" onChange={(e) => setForm({ ...form, id: e.target.value.toLowerCase() })} /></Label>
            <Label text={t(lang, "name")}><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Label>
            <Label text={t(lang, "baseUrl")}><Input value={form.base_url} placeholder={kind?.default_base_url ?? "https://…/v1"} onChange={(e) => setForm({ ...form, base_url: e.target.value })} /></Label>
            <Label text={t(lang, "apiKey")}><Input type="password" autoComplete="off" value={form.api_key} onChange={(e) => setForm({ ...form, api_key: e.target.value })} /></Label>
            <Label text={t(lang, "apiKeyEnv")}><Input value={form.api_key_env} placeholder={kind?.default_key_env ?? ""} onChange={(e) => setForm({ ...form, api_key_env: e.target.value })} /></Label>
            <Label text={t(lang, "priority")}><Input type="number" value={form.priority} onChange={(e) => setForm({ ...form, priority: Number(e.target.value) })} /></Label>
          </div>
          <p className="text-xs text-slate-500">{t(lang, "keyHelp")}</p>
          <Btn onClick={add} disabled={!form.id || busy === "add"}>{busy === "add" ? <Spinner /> : t(lang, "add")}</Btn>
        </Card>
      )}
    </div>
  );
}
