import { useEffect, useState } from "react";
import { api, ApiError } from "../api";
import { Key, t } from "../i18n";
import { Badge, Card, ErrorBox, Spinner, statusTone } from "../components/ui";
import type { PageProps } from "../App";

export default function Usage({ lang }: PageProps) {
  const [data, setData] = useState<any | null>(null);
  const [recent, setRecent] = useState<any[]>([]);
  const [err, setErr] = useState("");
  useEffect(() => {
    api("/usage").then(setData).catch((e: ApiError) => setErr(e.message));
    api("/usage/recent").then(setRecent).catch(() => undefined);
  }, []);
  return (
    <div className="mx-auto max-w-6xl space-y-4">
      <h1 className="text-xl font-bold">{t(lang, "nav_usage")}</h1>
      <ErrorBox message={err} />
      {!data && !err && <Spinner />}
      <p className="text-xs text-slate-500">{t(lang, "quotaNote")}</p>
      <div className="grid gap-3 md:grid-cols-2">
        {data?.providers.map((p: any) => (
          <Card key={p.id} className="space-y-2 text-sm">
            <div className="flex items-center justify-between"><strong>{p.name}</strong>
              <Badge tone={statusTone(p.status)}>{t(lang, `st_${p.status}` as Key)}</Badge></div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div><div className="text-lg">{p.requests}</div><div className="text-xs text-slate-400">{t(lang, "requests")}</div></div>
              <div><div className="text-lg text-emerald-300">{p.successful}</div><div className="text-xs text-slate-400">{t(lang, "successful")}</div></div>
              <div><div className="text-lg text-red-300">{p.failed}</div><div className="text-xs text-slate-400">{t(lang, "failed")}</div></div>
            </div>
            <div className="text-xs text-slate-400">{t(lang, "tokens")}: {p.prompt_tokens + p.completion_tokens || t(lang, "unknown")} ·
              {" "}{t(lang, "cost")}: {p.est_cost_usd != null ? `$${p.est_cost_usd.toFixed(4)}` : "—"} ·
              {" "}{t(lang, "lastSuccess")}: {p.last_success ?? "—"}</div>
            {Object.keys(p.errors_by_type).length > 0 && <div className="flex flex-wrap gap-1">
              {Object.entries(p.errors_by_type).map(([k, v]) => <Badge key={k} tone="bad">{k}: {String(v)}</Badge>)}</div>}
            <div className="text-xs">{t(lang, "quota")}: <Badge tone={p.quota.status === "provider_reported" ? "ok" : "mute"}>{t(lang, `q_${p.quota.status}` as Key)}</Badge>
              {p.quota.provider_reported && <span className="ms-2 text-slate-400">{Object.entries(p.quota.provider_reported).filter(([k]) => k !== "source" && k !== "observed_at").map(([k, v]) => `${k}=${v}`).join(" ")}</span>}</div>
          </Card>))}
      </div>
      <Card>
        <h2 className="mb-2 font-medium">{t(lang, "recent")}</h2>
        {recent.length === 0 ? <p className="text-sm text-slate-400">{t(lang, "empty")}</p> : (
          <div className="overflow-x-auto"><table className="w-full text-xs">
            <tbody>{recent.map((r, i) => (
              <tr key={i} className="border-t border-ink-700"><td className="p-1">{r.ts.slice(11, 19)}</td><td className="p-1">{r.provider}/{r.model}</td>
                <td className="p-1">{r.task}</td><td className="p-1">{r.latency_ms} ms</td>
                <td className="p-1"><Badge tone={r.success ? "ok" : "bad"}>{r.success ? "ok" : r.error_type}</Badge></td></tr>))}</tbody></table></div>)}
      </Card>
    </div>
  );
}
