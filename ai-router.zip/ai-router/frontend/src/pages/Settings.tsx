import { useState } from "react";
import { api, ApiError, getToken, setToken } from "../api";
import { Lang, t } from "../i18n";
import { Badge, Btn, Card, ErrorBox, Input, Label, Select } from "../components/ui";
import type { PageProps } from "../App";

export default function Settings({ lang, meta, setLang, reload }: PageProps & { setLang: (l: Lang) => void; reload: () => void }) {
  const [sys, setSys] = useState({ ...meta.system });
  const [token, setTok] = useState(getToken());
  const [err, setErr] = useState(""); const [ok, setOk] = useState(false);
  const admin = meta.user.role === "admin";

  const save = async () => {
    setErr(""); setOk(false);
    try {
      await api("/system", { method: "PUT", body: sys });
      setOk(true); reload();
    } catch (e) { setErr((e as ApiError).message); }
  };
  const lim = (v: number | null) => (v == null ? "" : String(v));
  const toLim = (s: string) => (s === "" ? null : Number(s));

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <h1 className="text-xl font-bold">{t(lang, "nav_settings")}</h1>
      <ErrorBox message={err} />
      <Card className="space-y-3">
        <Label text={t(lang, "language")}>
          <Select value={lang} onChange={(e) => setLang(e.target.value as Lang)}>
            <option value="ar">العربية</option><option value="en">English</option></Select></Label>
        <Label text={t(lang, "accessToken")}>
          <Input type="password" autoComplete="off" value={token} onChange={(e) => setTok(e.target.value)}
            onBlur={() => { setToken(token); reload(); }} /></Label>
        <p className="text-xs text-slate-500">{t(lang, "tokenHelp")}</p>
      </Card>
      <Card className="space-y-3">
        <Label text={t(lang, "defaultLang")}><Select disabled={!admin} value={sys.default_language}
          onChange={(e) => setSys({ ...sys, default_language: e.target.value as Lang })}>
          <option value="ar">العربية</option><option value="en">English</option></Select></Label>
        <Label text={t(lang, "maxContext")}><Input type="number" min={2} max={100} disabled={!admin} value={sys.max_context_messages}
          onChange={(e) => setSys({ ...sys, max_context_messages: Number(e.target.value) })} /></Label>
        <Label text={t(lang, "dailyReq")}><Input type="number" min={0} disabled={!admin} value={lim(sys.user_daily_request_limit)}
          onChange={(e) => setSys({ ...sys, user_daily_request_limit: toLim(e.target.value) })} /></Label>
        <Label text={t(lang, "dailyTok")}><Input type="number" min={0} disabled={!admin} value={lim(sys.user_daily_token_limit)}
          onChange={(e) => setSys({ ...sys, user_daily_token_limit: toLim(e.target.value) })} /></Label>
        {admin && <div className="flex items-center gap-3"><Btn onClick={save}>{t(lang, "save")}</Btn>{ok && <Badge tone="ok">{t(lang, "saved")}</Badge>}</div>}
      </Card>
    </div>
  );
}
