import { useEffect, useRef, useState } from "react";
import { api, ApiError } from "../api";
import { Key, t } from "../i18n";
import { Badge, Btn, Card, ErrorBox, Select, Spinner } from "../components/ui";
import type { PageProps } from "../App";

interface Msg { role: "user" | "assistant"; content: string; meta?: any }
interface Cmp { provider: string; model: string; ok: boolean; content?: string; error_type?: string; latency_ms: number }

export default function Chat({ lang, meta, openConv, setOpenConv }: PageProps) {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [mode, setMode] = useState("auto");
  const [task, setTask] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [cmp, setCmp] = useState<Cmp[] | null>(null);
  const [caps, setCaps] = useState<Record<string, { available: boolean }>>({});
  const [mediaOut, setMediaOut] = useState<{ kind: string; src: string } | null>(null);
  const end = useRef<HTMLDivElement>(null);

  useEffect(() => { api("/capabilities").then(setCaps).catch(() => undefined); }, []);
  useEffect(() => {
    if (openConv == null) { setMsgs([]); return; }
    api(`/conversations/${openConv}`).then((c) =>
      setMsgs(c.messages.map((m: any) => ({ role: m.role, content: m.content, meta: m.provider ? { provider: m.provider, model: m.model } : undefined }))),
    ).catch((e: ApiError) => setErr(e.message));
  }, [openConv]);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, cmp, busy]);

  const explain = (e: ApiError) => {
    const d: any = e.detail;
    if (e.code === "no_eligible_model") return `${e.message}${lang === "ar" ? " — " + t(lang, "noProviders") : ""}`;
    if (e.code === "all_providers_failed" && d?.attempts)
      return `${e.message}: ` + d.attempts.map((a: any) => `${a.provider}/${a.model} (${a.error_type ?? "ok"})`).join(" → ");
    return e.message;
  };

  const send = async () => {
    const message = text.trim();
    if (!message || busy) return;
    setBusy(true); setErr(""); setCmp(null); setText("");
    setMsgs((m) => [...m, { role: "user", content: message }]);
    try {
      if (mode === "compare") {
        const r = await api("/compare", { method: "POST", body: { message, task: task || undefined } });
        setCmp(r.results);
      } else {
        const r = await api("/chat", { method: "POST", body: { message, mode, task: task || undefined, conversation_id: openConv ?? undefined } });
        setOpenConv(r.conversation_id);
        setMsgs((m) => [...m, { role: "assistant", content: r.content, meta: r }]);
      }
    } catch (e) { setErr(explain(e as ApiError)); } finally { setBusy(false); }
  };

  const media = async (kind: "image" | "tts") => {
    const prompt = text.trim();
    if (!prompt) return;
    setBusy(true); setErr(""); setMediaOut(null);
    try {
      const r = await api(`/media/${kind}`, { method: "POST", body: kind === "image" ? { prompt } : { text: prompt } });
      const res = r.result;
      if (kind === "image") setMediaOut({ kind, src: res.url ?? `data:image/png;base64,${res.b64_json}` });
      else setMediaOut({ kind, src: `data:${res.mime};base64,${res.audio_base64}` });
    } catch (e) { setErr(explain(e as ApiError)); } finally { setBusy(false); }
  };

  const modes = ["auto", "fast", "best", "free_first", "compare"];
  return (
    <div className="mx-auto flex h-full max-w-5xl flex-col gap-3">
      <div className="flex flex-wrap items-end gap-2">
        <div className="w-40"><Select aria-label={t(lang, "mode")} value={mode} onChange={(e) => setMode(e.target.value)}>
          {modes.map((m) => <option key={m} value={m}>{t(lang, `mode_${m}` as Key)}</option>)}</Select></div>
        <div className="w-44"><Select aria-label={t(lang, "task")} value={task} onChange={(e) => setTask(e.target.value)}>
          <option value="">{t(lang, "task")}: {t(lang, "auto")}</option>
          {meta.tasks.map((x) => <option key={x} value={x}>{x}</option>)}</Select></div>
        <Btn variant="ghost" onClick={() => { setOpenConv(null); setMsgs([]); setCmp(null); }}>{t(lang, "newChat")}</Btn>
      </div>
      {mode === "compare" && <p className="text-xs text-slate-400">{t(lang, "compareHint")}</p>}

      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto pe-1">
        {msgs.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <Card className={`max-w-[90%] whitespace-pre-wrap text-sm md:max-w-[75%] ${m.role === "user" ? "bg-ink-700" : ""}`}>
              {m.content}
              {m.meta?.provider && (
                <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-ink-700 pt-2 text-xs text-slate-400">
                  <Badge tone="ok">{t(lang, "answeredBy")}: {m.meta.provider} / {m.meta.model}</Badge>
                  {m.meta.task && <Badge>{m.meta.task}</Badge>}
                  {m.meta.fallback_used && <Badge tone="warn">{t(lang, "fallbackUsed")}</Badge>}
                  {m.meta.warnings?.length > 0 && <Badge tone="warn">{t(lang, "warnings")}: {m.meta.warnings.join(", ")}</Badge>}
                </div>
              )}
              {m.meta?.fallback_used && (
                <div className="mt-1 text-xs text-slate-500">{t(lang, "attempts")}: {m.meta.attempts.map((a: any) => `${a.provider}/${a.model}:${a.error_type ?? "ok"}`).join(" → ")}</div>
              )}
            </Card>
          </div>
        ))}
        {cmp && (
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {cmp.map((r, i) => (
              <Card key={i} className="text-sm">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <Badge tone={r.ok ? "ok" : "bad"}>{r.provider} / {r.model}</Badge>
                  <span className="text-xs text-slate-500">{r.latency_ms} ms</span>
                </div>
                {r.ok ? <div className="whitespace-pre-wrap">{r.content}</div> : <div className="text-red-300">{r.error_type}</div>}
              </Card>
            ))}
          </div>
        )}
        {mediaOut && <Card>{mediaOut.kind === "image" ? <img src={mediaOut.src} alt="generated" className="max-h-96 rounded-xl" /> : <audio controls src={mediaOut.src} />}</Card>}
        {busy && <div className="flex items-center gap-2 text-sm text-slate-400"><Spinner />{t(lang, "loading")}</div>}
        <div ref={end} />
      </div>

      <ErrorBox message={err} />
      <div className="flex flex-col gap-2">
        <textarea
          value={text} onChange={(e) => setText(e.target.value)} rows={3}
          placeholder={t(lang, "typeMessage")}
          onKeyDown={(e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) send(); }}
          className="w-full resize-none rounded-2xl border border-ink-700 bg-ink-900 p-3 text-sm outline-none focus:border-accent" />
        <div className="flex flex-wrap items-center gap-2">
          <Btn onClick={send} disabled={busy || !text.trim()}>{t(lang, "send")}</Btn>
          {caps.image_generation?.available && <Btn variant="ghost" onClick={() => media("image")} disabled={busy || !text.trim()}>{t(lang, "genImage")}</Btn>}
          {caps.audio_generation?.available && <Btn variant="ghost" onClick={() => media("tts")} disabled={busy || !text.trim()}>{t(lang, "genSpeech")}</Btn>}
        </div>
      </div>
    </div>
  );
}
