import { useEffect, useState } from "react";
import { api, ApiError, Provider } from "../api";
import { Key, t } from "../i18n";
import { Badge, Btn, Card, ErrorBox, Input, Label, Select, Spinner } from "../components/ui";
import type { PageProps } from "../App";

interface R {
  default_mode: string; max_total_attempts: number; transient_retries: number; request_timeout: number;
  compare_count: number; strict_fallback_order: boolean; fallback_order: string[];
}

export default function Routing({ lang, meta }: PageProps) {
  const [r, setR] = useState<R | null>(null);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [err, setErr] = useState(""); const [ok, setOk] = useState(false);
  const admin = meta.user.role === "admin";

  useEffect(() => {
    Promise.all([api<R>("/routing"), api<Provider[]>("/providers")]).then(([x, p]) => {
      setProviders(p);
      const known = p.map((q) => q.id);
      setR({ ...x, fallback_order: [...x.fallback_order.filter((i) => known.includes(i)), ...known.filter((i) => !x.fallback_order.includes(i))] });
    }).catch((e: ApiError) => setErr(e.message));
  }, []);
  if (!r) return err ? <ErrorBox message={err} /> : <Spinner />;

  const move = (i: number, d: number) => {
    const o = [...r.fallback_order]; const j = i + d;
    if (j < 0 || j >= o.length) return;
    [o[i], o[j]] = [o[j], o[i]]; setR({ ...r, fallback_order: o });
  };
  const save = async () => {
    setErr(""); setOk(false);
    try { await api("/routing", { method: "PUT", body: r }); setOk(true); } catch (e) { setErr((e as ApiError).message); }
  };
  const num = (k: keyof R) => (e: React.ChangeEvent<HTMLInputElement>) => setR({ ...r, [k]: Number(e.target.value) });

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <h1 className="text-xl font-bold">{t(lang, "nav_routing")}</h1>
      <ErrorBox message={err} />
      <Card className="grid gap-3 md:grid-cols-2">
        <Label text={t(lang, "defaultMode")}><Select value={r.default_mode} disabled={!admin} onChange={(e) => setR({ ...r, default_mode: e.target.value })}>
          {meta.modes.map((m) => <option key={m} value={m}>{t(lang, `mode_${m}` as Key)}</option>)}</Select></Label>
        <Label text={t(lang, "maxAttempts")}><Input type="number" min={1} max={12} disabled={!admin} value={r.max_total_attempts} onChange={num("max_total_attempts")} /></Label>
        <Label text={t(lang, "retries")}><Input type="number" min={0} max={3} disabled={!admin} value={r.transient_retries} onChange={num("transient_retries")} /></Label>
        <Label text={t(lang, "timeout")}><Input type="number" min={5} max={600} disabled={!admin} value={r.request_timeout} onChange={num("request_timeout")} /></Label>
        <Label text={t(lang, "compareCount")}><Input type="number" min={2} max={6} disabled={!admin} value={r.compare_count} onChange={num("compare_count")} /></Label>
        <label className="flex items-center gap-2 self-end text-sm">
          <input type="checkbox" disabled={!admin} checked={r.strict_fallback_order} onChange={(e) => setR({ ...r, strict_fallback_order: e.target.checked })} />
          {t(lang, "strictOrder")}</label>
      </Card>
      <Card className="space-y-2">
        <h2 className="font-medium">{t(lang, "fallbackOrder")}</h2>
        {r.fallback_order.map((id, i) => (
          <div key={id} className="flex items-center justify-between rounded-xl bg-ink-800 px-3 py-2 text-sm">
            <span><Badge>{i + 1}</Badge> {providers.find((p) => p.id === id)?.name ?? id}</span>
            {admin && <span className="flex gap-1"><Btn variant="ghost" onClick={() => move(i, -1)}>↑</Btn><Btn variant="ghost" onClick={() => move(i, 1)}>↓</Btn></span>}
          </div>))}
      </Card>
      {admin && <div className="flex items-center gap-3"><Btn onClick={save}>{t(lang, "save")}</Btn>{ok && <Badge tone="ok">{t(lang, "saved")}</Badge>}</div>}
    </div>
  );
}
