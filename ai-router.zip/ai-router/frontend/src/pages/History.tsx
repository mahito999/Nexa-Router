import { useEffect, useState } from "react";
import { api, ApiError } from "../api";
import { t } from "../i18n";
import { Btn, Card, ErrorBox, Spinner } from "../components/ui";
import type { PageProps } from "../App";

export default function History({ lang, go, setOpenConv }: PageProps) {
  const [items, setItems] = useState<{ id: number; title: string; updated_at: string }[] | null>(null);
  const [err, setErr] = useState("");
  const load = () => api("/conversations").then(setItems).catch((e: ApiError) => setErr(e.message));
  useEffect(() => { load(); }, []);

  const act = async (fn: () => Promise<unknown>) => { setErr(""); try { await fn(); await load(); } catch (e) { setErr((e as ApiError).message); } };
  return (
    <div className="mx-auto max-w-3xl space-y-3">
      <h1 className="text-xl font-bold">{t(lang, "history")}</h1>
      <ErrorBox message={err} />
      {!items && !err && <Spinner />}
      {items?.length === 0 && <p className="text-slate-400">{t(lang, "empty")}</p>}
      {items?.map((c) => (
        <Card key={c.id} className="flex flex-wrap items-center justify-between gap-2">
          <div><div className="font-medium">{c.title || `#${c.id}`}</div><div className="text-xs text-slate-500">{c.updated_at.replace("T", " ").slice(0, 16)}</div></div>
          <div className="flex gap-2">
            <Btn onClick={() => { setOpenConv(c.id); go("chat"); }}>{t(lang, "open")}</Btn>
            <Btn variant="ghost" onClick={() => { const title = prompt(t(lang, "rename"), c.title); if (title) act(() => api(`/conversations/${c.id}`, { method: "PATCH", body: { title } })); }}>{t(lang, "rename")}</Btn>
            <Btn variant="danger" onClick={() => confirm(t(lang, "confirmDelete")) && act(() => api(`/conversations/${c.id}`, { method: "DELETE" }))}>{t(lang, "delete")}</Btn>
          </div>
        </Card>))}
    </div>
  );
}
