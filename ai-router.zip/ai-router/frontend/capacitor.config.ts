import type { CapacitorConfig } from "@capacitor/cli";

// The APK bundles the built web UI (dist/). The API is NOT inside the app:
// enter your server address on first launch (Settings -> Server URL).
const config: CapacitorConfig = {
  appId: "com.airouter.app",
  appName: "AI Router",
  webDir: "dist",
  server: {
    // Page origin becomes http://localhost, so add it to CORS_ORIGINS on the server.
    androidScheme: "http",
    // Lets the app talk to http:// servers on your LAN (https:// works too).
    cleartext: true,
  },
};

export default config;
