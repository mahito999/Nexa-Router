/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { ink: { 950: "#0b0d12", 900: "#11141b", 800: "#181c26", 700: "#232836" }, accent: "#7c9cff" },
      fontFamily: { sans: ["Tajawal", "Segoe UI", "Noto Sans Arabic", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
};
