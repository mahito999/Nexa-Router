# Nexora AI for Android

Native Android application written in Kotlin + Jetpack Compose. It connects to the existing Nexora AI FastAPI backend. Provider API keys must remain on the backend and must never be placed in this app.

## Requirements
- Android Studio (recommended) with JDK 17 and Android SDK 35
- Existing Nexora backend deployed with HTTPS
- Optional bearer token matching `AI_ROUTER_API_TOKENS` on the backend

## Build
Open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Or run `gradle assembleDebug` with Gradle and Android SDK installed. GitHub Actions also builds a debug APK and uploads it as an artifact.

## Configure
Install the app, tap the gear icon, enter your backend HTTPS URL (for example `https://api.your-domain.com`) and optional bearer token, then save. The app sends messages to `POST /api/chat` using `mode=auto`.

## Security
- Never add OpenAI/Gemini/Anthropic API keys to the Android app. APK contents can be inspected.
- Configure provider keys only in the backend environment.
- Use HTTPS. Cleartext HTTP is disabled.
- The optional backend bearer token is stored using Android EncryptedSharedPreferences. For public production use, add real user authentication and short-lived tokens; do not distribute a shared admin token in an APK.

## Current scope
Chat screen, Arabic-first UI, backend URL/token settings, auto-routing via backend, conversation continuity during the current app session. This is an Android client, not a self-contained on-device model. Image/audio generation and conversation history UI are not included yet.
