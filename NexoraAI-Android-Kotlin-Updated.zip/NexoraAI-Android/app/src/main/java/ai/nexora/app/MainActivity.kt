package ai.nexora.app

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val masterKey = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        val prefs = EncryptedSharedPreferences.create(this, "nexora_secure", masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
        setContent { NexoraApp(prefs) }
    }
}

data class ChatLine(val role: String, val text: String, val model: String = "")
data class ChatReply(val conversation_id: Long, val content: String, val provider: String?, val model: String?, val task: String?)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NexoraApp(prefs: android.content.SharedPreferences) {
    var baseUrl by remember { mutableStateOf(prefs.getString("base_url", "https://YOUR-SERVER.example.com") ?: "") }
    var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var conversationId by remember { mutableStateOf<Long?>(null) }
    val messages = remember { mutableStateListOf<ChatLine>() }
    val client = remember { OkHttpClient.Builder().callTimeout(120, TimeUnit.SECONDS).build() }
    val gson = remember { Gson() }
    val dark = Color(0xFF10131B)
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF8B9CFF), background = dark, surface = Color(0xFF1A1F2B))) {
        Scaffold(containerColor = dark, topBar = {
            TopAppBar(title = { Column { Text("Nexora AI", fontWeight = FontWeight.Bold); Text("مساعدك الذكي", style = MaterialTheme.typography.labelSmall, color = Color.LightGray) } },
                actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "الإعدادات") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = dark, titleContentColor = Color.White))
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
                if (messages.isEmpty()) {
                    Spacer(Modifier.height(70.dp))
                    Text("مرحبًا بك في Nexora AI", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("اسأل، اكتب، حلّل، أو اطلب المساعدة في البرمجة.", color = Color.LightGray, modifier = Modifier.padding(top = 8.dp))
                    Spacer(Modifier.height(18.dp))
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), reverseLayout = false, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages) { line ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.role == "user") Arrangement.End else Arrangement.Start) {
                            Column(Modifier.widthIn(max = 320.dp).background(if (line.role == "user") Color(0xFF303D68) else Color(0xFF202735), RoundedCornerShape(16.dp)).padding(12.dp)) {
                                Text(if (line.role == "user") "أنت" else "Nexora", color = Color(0xFFB9C5FF), style = MaterialTheme.typography.labelSmall)
                                Spacer(Modifier.height(4.dp))
                                Text(line.text, color = Color.White)
                                if (line.model.isNotBlank()) Text(line.model, color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), modifier = Modifier.padding(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("اكتب رسالتك...") }, maxLines = 4, enabled = !busy)
                    IconButton(enabled = !busy && input.isNotBlank(), onClick = {
                        val prompt = input.trim()
                        input = ""; error = ""; messages.add(ChatLine("user", prompt)); busy = true
                        val payload = mutableMapOf<String, Any>("message" to prompt, "mode" to "auto")
                        conversationId?.let { payload["conversation_id"] = it }
                        val body = gson.toJson(payload).toRequestBody("application/json".toMediaType())
                        val req = Request.Builder().url(baseUrl.trimEnd('/') + "/api/chat").post(body)
                            .header("Content-Type", "application/json").apply { if (token.isNotBlank()) header("Authorization", "Bearer $token") }.build()
                        client.newCall(req).enqueue(object : Callback {
                            override fun onFailure(call: Call, e: IOException) {
                                Handler(Looper.getMainLooper()).post { busy = false; error = "تعذر الاتصال بالخادم: ${e.message}" }
                            }
                            override fun onResponse(call: Call, response: Response) {
                                val raw = response.body?.string().orEmpty()
                                Handler(Looper.getMainLooper()).post {
                                    busy = false
                                    if (!response.isSuccessful) error = "خطأ ${response.code}: $raw"
                                    else try {
                                        val result = gson.fromJson(raw, ChatReply::class.java)
                                        conversationId = result.conversation_id
                                        messages.add(ChatLine("assistant", result.content, "${result.provider ?: ""} • ${result.model ?: ""}"))
                                    } catch (_: Exception) { error = "استجابة غير مفهومة من الخادم" }
                                }
                                response.close()
                            }
                        })
                    }) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Send, "إرسال", tint = Color.White) }
                }
            }
        }
        if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("إعدادات الاتصال") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("رابط خادم Nexora (HTTPS)")
                OutlinedTextField(baseUrl, { baseUrl = it }, singleLine = true, placeholder = { Text("https://api.example.com") })
                Text("رمز الدخول (Bearer Token)، اتركه فارغًا إذا عطّلت المصادقة على خادم خاص")
                OutlinedTextField(token, { token = it }, singleLine = true)
            } },
            confirmButton = { TextButton(onClick = {
                prefs.edit().putString("base_url", baseUrl.trim()).putString("token", token).apply()
                showSettings = false
            }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = { showSettings = false }) { Text("إلغاء") } })
    }
}

